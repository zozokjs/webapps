package com.mf.action.manger;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mf.action.Action;

public class SendMessage implements Action{
	//해당 판매자에게 쪽지를 보내는 액션
	//(아직 액션팩토리에 들어가있지않음)
	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws IOException {
		
	}
}
