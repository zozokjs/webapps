package com.mf.action.buyer;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.mf.action.Action;
import com.mf.dao.ProductDAO;
import com.mf.dto.ProductVO;

public class B_BuyerOrders implements Action{
	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		System.out.println("--확인용-- B_BuyerOrder.java 진입");
		//여기서 해야 할 거~ mid를 통해 등록된 물품을 
		HttpSession ses = request.getSession();
		String mid = (String)ses.getAttribute("mid"); 
				
		ProductDAO pdao = ProductDAO.getInstance();		
		List<ProductVO> product = pdao.selectAllBySeller(mid);
		//여기서 id(사용자)가 구매한거 가져와야해
			
		request.setAttribute("mid", mid);		
		request.setAttribute("product", product);
		
		RequestDispatcher dispatcher = request.getRequestDispatcher("Buyer/B_BuyerOrder.jsp");
		dispatcher.forward(request, response);
	
		System.out.println("--확인용-- B_BuyerOrder.java 다 읽음");
		
		
		
	}

}
