package com.mf.action.buyer;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.mf.action.Action;
import com.mf.dao.OrderingDAO;
import com.mf.dao.ProductDAO;
import com.mf.dto.OrderingVO;
import com.mf.dto.PandOVO;
import com.mf.dto.ProductVO;

public class B_BuyerBasketView implements Action
{

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {		
		System.out.println("--확인용-- B_BuyerBasketView.java 진입");
		
		HttpSession session = request.getSession();
		String mid = (String) session.getAttribute("mid"); //구매자 아이디 / 받아오는거 확인
			
		//String pprice = request.getParameter("pprice");
		//System.out.println("pprice>>>>>>>>>>>>> "+pprice);
		System.out.println("mid>>>>>>>>>>>>> "+mid);
		
		
		/*int pprice2 = Integer.parseInt(pprice);
		System.out.println(pprice);*/
		
		/*String pname= request.getParameter("pname");
		String pauthor= request.getParameter("pauthor");*/
		
		
		
		OrderingDAO odao = OrderingDAO.getInstance();
		List<PandOVO> order = odao.selectAllByMidOrdering(mid);
		
		//상품 가격 얻어와야함
/*		int pnumber = 0;
		ProductVO product = null;
		
		pnumber = order.get(0).getPnumber();
		ProductDAO pdao = ProductDAO.getInstance();
		product = pdao.selectOneProduct(pnumber);
			*/
/*		request.setAttribute("pprice", pprice2);
		request.setAttribute("pname", pname);
		request.setAttribute("pauthor", pauthor);*/
		request.setAttribute("order", order);
		
		RequestDispatcher dis = request.getRequestDispatcher("Buyer/B_BuyerBasketView.jsp");
		dis.forward(request, response);
		
		
		System.out.println("B_BuyerOrder.java 통과");
	}

}
