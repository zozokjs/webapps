package com.mf.action.seller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mf.action.Action;
import com.mf.dao.ProductDAO;
import com.mf.dto.ProductVO;

public class S_SellerProductUpdate implements Action{

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		System.out.println("--확인용-- 여기는 S_SellerProductUpdate");
		ProductVO po = (ProductVO)request.getAttribute("product");
		ProductDAO pdao = ProductDAO.getInstance();
		pdao.updateProduct(po);
		
		int pnumber = po.getPnumber();
		//System.out.println("bnumber>>>>>>>>>>>>>>>>>>>  "+pnumber);
		//request.setAttribute("bnumber", bnumber);
		
		RequestDispatcher dispatcher = request.getRequestDispatcher("MFServlet?command=S_SellerProductDetail&pnumber="+pnumber);
		dispatcher.forward(request, response);
		System.out.println("S_SellerProductUpdate 다 읽음");
		
	}

}
