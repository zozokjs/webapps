package com.mf.action.main;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.catalina.Session;

import com.mf.action.Action;
import com.mf.dao.ProductDAO;
import com.mf.dto.ProductVO;

public class MainPage2	implements Action
{

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		//조건문을 줄까? 
		//
		System.out.println("--확인용-- MainPage2.java 진입");
/*		HttpSession session = request.getSession();
		String mid = (String) request.getParameter("mid");
		String mname = (String) request.getParameter("mname");
		String mgrade = (String) request.getParameter("mgrade");
				
		System.out.println("mid는>>>>>>>>"+request.getAttribute("mid"));
		System.out.println("mname는>>>>>>>>"+request.getAttribute("mname"));
		System.out.println("mgrade는>>>>>>>>"+request.getAttribute("mgrade"));*/
				
		String mid = request.getParameter("mid");
		String mname = request.getParameter("mname");
		String mgrade = request.getParameter("mgrade");
		int mgrade2 = Integer.parseInt(mgrade);
		
		System.out.println("mid는>>>>>>>>"+mid);
		System.out.println("mname는>>>>>>>>"+mname);
		System.out.println("mgrade는>>>>>>>>"+mgrade2);
			
		
		//화면에 최근 등록 상품 출력
		ProductDAO pdao = ProductDAO.getInstance();
		List<ProductVO> Productlist = pdao.selectAllByDate();
		request.setAttribute("Productlist", Productlist);
		//화면에 최근 등록 상품 출력
		
		
		request.setAttribute("mid", mid); //필수
		request.setAttribute("mname", mname); //필수
		request.setAttribute("mgrade", mgrade2);  //필수  //int형으로 변환하고 넘겨야 한다.
		
		RequestDispatcher dispatcher = request.getRequestDispatcher("Main/MainPage2.jsp");
		dispatcher.forward(request,response);	
		
		System.out.println("--확인용-- MainPage2.java 다 읽음");
		
	}

}
