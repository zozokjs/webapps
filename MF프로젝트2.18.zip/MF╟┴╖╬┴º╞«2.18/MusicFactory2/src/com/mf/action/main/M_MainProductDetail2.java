package com.mf.action.main;

import java.io.IOException;
import java.sql.Timestamp;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mf.action.Action;
import com.mf.dao.ProductDAO;
import com.mf.dto.ProductVO;

public class M_MainProductDetail2 implements Action
{

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("--확인용-- M_MainProductDetail2 진입");
		
		String pnumber = request.getParameter("pnumber");
		int pnumber2 = Integer.parseInt(pnumber);
		ProductDAO dao = ProductDAO.getInstance();
		ProductVO product = dao.selectOneProduct(pnumber2);
		
		String pauthor = product.getPauthor();
		Timestamp pdate=product.getPdate();
		String pjanre =product.getPjanre();
		int pnumber3 =product.getPnumber();
		String ppicture =product.getPpicture();
		int pprice = product.getPprice();
		int pscore = product.getPscore();
		String pname =product.getPname();
		//String mid = product.getMid();
	
		request.setAttribute("ppicture",ppicture);			
		request.setAttribute("pnumber",pnumber3);		
		request.setAttribute("pname",pname);
		request.setAttribute("pprice",pprice);
		request.setAttribute("pauthor",pauthor);
		request.setAttribute("pjanre",pjanre);
		request.setAttribute("pdate",pdate);		
		request.setAttribute("pscore",pscore);
		RequestDispatcher dispatcher = request.getRequestDispatcher("Main/M_MainProductDetail2.jsp");
		dispatcher.forward(request, response);
		
		System.out.println("M_MainProductDetail2 다 읽음");
	}

}
