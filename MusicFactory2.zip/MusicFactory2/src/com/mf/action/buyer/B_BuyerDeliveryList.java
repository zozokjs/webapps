package com.mf.action.buyer;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mf.action.Action;

public class B_BuyerDeliveryList implements Action{

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("--확인용--  B_BuyerDeliveryList.java 진입 ");
		List<String> a =new ArrayList<String>();
		/*while(request.getParameter("onumber") != null)
		{
			a.add(request.getParameter("onumber"));
		}*/
		
		String b = request.getParameter("onumber");
		String c = request.getParameter("onumber");
		String d = request.getParameter("onumber");
		System.out.println(b+" -");
		System.out.println(c+" -");
		System.out.println(d+" -");
		
		System.out.println(">>>> "+a.size());
		System.out.println("B_BuyerDeliveryList.java 다 읽음");
		
	}

}
