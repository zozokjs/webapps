package com.mf.action.buyer;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mf.action.Action;
import com.mf.dao.OrderingDAO;

public class B_BuyerOrderEdit implements Action
{

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("--확인용-- 여기는 B_BuyerOrderEdit.java 진입 ");
		
		String onumber = request.getParameter("onumber"); //장바구니 번호
		String ovolume = request.getParameter("ovolumeEdit"); //구매자가 수정한 물품 갯수
		
		System.out.println("입력한 갯수>> "+ovolume);
		
		int onumber2 = Integer.parseInt(onumber);
		int ovolume2 = Integer.parseInt(ovolume);
		
		OrderingDAO odao = OrderingDAO.getInstance();
		odao.EditOrdering(onumber2, ovolume2);
		
		RequestDispatcher dispatcher = request.getRequestDispatcher("MFServlet?command=B_BuyerBasketView");
		dispatcher.forward(request, response);
		
		System.out.println("B_BuyerOrderEdit.java 다 읽음");
		
	}


	

}
