package com.mf.action.buyer;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.mf.action.Action;
import com.mf.dao.BoardDAO;
import com.mf.dto.BoardVO;

public class B_BuyerOrder implements Action{
	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		System.out.println("--Ȯ�ο�-- B_BuyerOrder.java ����");
		//���⼭ �ؾ� �� ��~ mid�� ���� ��ϵ� ��ǰ�� 
		HttpSession ses = request.getSession();
		String mid = (String)ses.getAttribute("mid"); 
				
		BoardDAO dao = BoardDAO.getInstance();		
		List<BoardVO> board = dao.selectAllBySeller(mid);
		//���⼭ id(�����)�� �����Ѱ� �����;���
			
		request.setAttribute("mid", mid);		
		request.setAttribute("board", board);
		
		RequestDispatcher dispatcher = request.getRequestDispatcher("Buyer/B_BuyerOrder.jsp");
		dispatcher.forward(request, response);
	
		System.out.println("--Ȯ�ο�-- B_BuyerOrder.java �� ����");
		
		
		
	}

}
