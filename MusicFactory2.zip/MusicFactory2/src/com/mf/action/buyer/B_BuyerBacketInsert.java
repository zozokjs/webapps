package com.mf.action.buyer;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.mf.action.Action;
import com.mf.dao.OrderingDAO;
import com.mf.dao.ProductDAO;
import com.mf.dto.OrderingVO;
import com.mf.dto.ProductVO;

public class B_BuyerBacketInsert implements Action
{

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("--확인용-- B_BuyerBacketInsert.java 진입");
		
		HttpSession session = request.getSession();
		String mid = (String) session.getAttribute("mid"); //구매자 아이디
	
		String ovolume = request.getParameter("ovolume"); //수량
		int ovolume2 = Integer.parseInt(ovolume);
		
		String pnumber = request.getParameter("pnumber"); //구매 상품 번호	
		int pnumber2 = Integer.parseInt(pnumber);
		
		String otf = request.getParameter("otf"); //구매 전후 구분 번호	
		int otf2 = Integer.parseInt(otf);
			
			
		/*ProductDAO pdao = ProductDAO.getInstance();
		ProductVO product = pdao.selectOneProduct(pnumber2); //pnumber에 대한 정보 받아 옴	
		
		String pname = product.getPname(); //상품명
		String pauthor = product.getPauthor(); //상품제작자
		int pprice = product.getPprice(); 
		System.out.println("B_BuyerBacketInsert의 pprice>>>>>>>>>>>>>"+pprice);
		
		*/
		//String pprice2 = Integer.toString(pprice); //상품가격
	
			
		OrderingVO order = new OrderingVO();
		order.setMid(mid);
		order.setPnumber(pnumber2);
		order.setOvolume(ovolume2);
		order.setOtf(otf2);
			
		OrderingDAO odao = OrderingDAO.getInstance();
		odao.insertOrdering(order); 
		//주문 목록 테이블에 String형의 아이디, int형의 상품 번호, 상품 수량 넘김
		
		response.sendRedirect("MFServlet?command=B_BuyerBasketView");
		//dis.forward(request, response);
		
		
		System.out.println("B_BuyerOrder.java 통과");
		
	}

}
