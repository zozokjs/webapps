package com.mf.action.buyer;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mf.action.Action;
import com.mf.dao.OrderingDAO;

public class B_BuyerOrderDelete implements Action
{

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("--확인용-- 여기는 B_BuyerOrderDelete ");
		
		String onumber = request.getParameter("onumber");
		int onumber2 = Integer.parseInt(onumber);
		
		OrderingDAO odao = OrderingDAO.getInstance();
		odao.DeleteOrdering(onumber2);
		
		RequestDispatcher dispatcher = request.getRequestDispatcher("MFServlet?command=B_BuyerBasketView");
		dispatcher.forward(request, response);
		System.out.println("B_BuyerOrderDelete 다 읽음");
		
		
	}

}
