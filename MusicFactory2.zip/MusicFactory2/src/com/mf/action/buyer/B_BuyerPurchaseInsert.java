package com.mf.action.buyer;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.mf.action.Action;
import com.mf.dao.MemberDAO;
import com.mf.dao.OrderingDAO;
import com.mf.dto.MemberVO;
import com.mf.dto.PandOVO;

public class B_BuyerPurchaseInsert implements Action
{

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("--확인용-- 여기는 B_BuyerPurchaseInsert.java ");
		
		HttpSession session = request.getSession();
		String mid = (String) session.getAttribute("mid"); //전달 확인 됨
		MemberDAO mdao = MemberDAO.getInstance();		
		MemberVO member = mdao.selectOneMember(mid); //DB에서 mid 조회하여 모든 정보 얻음
		
		request.setAttribute("mid",member.getMid()); //아이디
		request.setAttribute("mname",member.getMname()); //이름
		request.setAttribute("mgrade",member.getMgrade());//회원 등급
		request.setAttribute("mphone",member.getMphone());//회원 전번
		request.setAttribute("maddr",member.getMaddr());//회원 주소
		request.setAttribute("memail",member.getMemail());//회원 이메일
		
		OrderingDAO odao = OrderingDAO.getInstance();
		List<PandOVO> order = odao.selectAllByMidOrdering(mid);
		//구매 수량, 구매혹은장바구니 번호, 구매 전후 파악 번호(0이면 구매 전. 1이면 구매 후(결제 후)),
		//제품 수량(재고), 제품제작자, 제품등록날짜,제품장르,제품번호,제품그림,제품가격,제품평점 얻음
		
		request.setAttribute("order", order);
		
		String totalPrice = odao.sumTotalPrice(mid); //장바구니 총 가격. String 리턴됨
		request.setAttribute("totalPrice", totalPrice);
		
		RequestDispatcher dis = request.getRequestDispatcher("Buyer/B_BuyerPurchaseInsert.jsp");
		dis.forward(request, response);
		
		
		System.out.println("B_BuyerPurchaseInsert.java 통과");
		
		
		
	}

}
