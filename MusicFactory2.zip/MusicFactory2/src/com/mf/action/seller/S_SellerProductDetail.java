package com.mf.action.seller;

import java.io.IOException;
import java.sql.Timestamp;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mf.action.Action;
import com.mf.dao.ProductDAO;
import com.mf.dto.ProductVO;

public class S_SellerProductDetail implements Action
{

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("--확인용-- 여기는 S_SellerProductDetail ");
				
		//S_SellerBoardEdit.jsp에서는 bnumber를 Parameter로 넘김
		//S_SellerMain.jsp에서는 bnumber를 Parameter로 넘김
		//S_SellerBoardUpdate.java에서 bnumber를 Attribute로 넘김
		
		String a= request.getParameter("pnumber");
	
		int pnumber = Integer.parseInt(a);
		//int bnumber = (int) request.getAttribute("bnumber");
		ProductDAO pdao = ProductDAO.getInstance();
		ProductVO product = pdao.selectOneProduct(pnumber);
		
		
		String pauthor = product.getPauthor();
		Timestamp pdate=product.getPdate();
		String pjanre =product.getPjanre();
		int pnumber3 =product.getPnumber();
		String ppicture =product.getPpicture();
		int pprice = product.getPprice();
		int pscore = product.getPscore();
		String pname =product.getPname();
		String pyoutube = product.getPyoutube();
		//String mid = board.getMid();
	
		request.setAttribute("ppicture",ppicture);			
		request.setAttribute("pnumber",pnumber3);		
		request.setAttribute("pname",pname);
		request.setAttribute("pprice",pprice);
		request.setAttribute("pauthor",pauthor);
		request.setAttribute("pjanre",pjanre);
		request.setAttribute("pdate",pdate);		
		request.setAttribute("pscore",pscore);
		request.setAttribute("pyoutube", pyoutube);
		
		RequestDispatcher dispatcher = request.getRequestDispatcher("Seller/S_SellerProductDetail.jsp");
		dispatcher.forward(request, response);
		
		System.out.println("S_SellerProductDetail 다 읽음");
		
	}

}
