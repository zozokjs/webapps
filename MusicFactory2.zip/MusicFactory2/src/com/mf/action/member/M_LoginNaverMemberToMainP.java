package com.mf.action.member;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mf.action.Action;
import com.mf.dao.ProductDAO;
import com.mf.dto.ProductVO;

public class M_LoginNaverMemberToMainP implements Action{

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("--확인용-- M_LoginNaverMemberToMainP.java 진입");
		
		String mid = (String) request.getParameter("mid"); //아이디
		request.setAttribute("mid",mid);
		
		String mname = (String) request.getParameter("mname"); //회원 본명?
		request.setAttribute("mname",mname);
			
		String mgrade2 = (String)request.getParameter("mgrade"); //회원 등급
		int mgrade = Integer.parseInt(mgrade2);
		request.setAttribute("mgrade",mgrade);
		
	    ProductDAO pdao = ProductDAO.getInstance();
		List<ProductVO> Productlist = pdao.selectAllByDate();
		request.setAttribute("Productlist", Productlist);
		
		System.out.println("mid ---> "+mid);
		System.out.println("mname ---> "+mname);
		System.out.println("mgrade ---> "+mgrade);
		
		RequestDispatcher dispatcher = request.getRequestDispatcher("Main/MainPage2.jsp");
		dispatcher.forward(request,response);	
		
	}
	

}
