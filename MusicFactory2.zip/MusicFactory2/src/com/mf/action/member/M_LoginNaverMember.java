package com.mf.action.member;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import com.mf.action.Action;
import com.mf.dao.MemberDAO;
import com.mf.dao.ProductDAO;
import com.mf.dto.MemberVO;
import com.mf.dto.ProductVO;

public class M_LoginNaverMember implements Action {
	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		System.out.println("--확인용-- M_LoginNaverMember.java 진입");
		
		HttpSession session = request.getSession();
		String access_token = (String)session.getAttribute("access_token");
		//1. access_token은 callback.jsp파일에서 세션에 저장하였으므로 여기서 getAttrivute를 써서 가져올 수 있다.
		
		String token = access_token;
		//2. token이라는 변수에 저장한다.
		
		String header = "Bearer " + token; // Bearer 다음에 공백 추가
		//3. 헤더에 저장
		try {
		    String apiURL = "https://openapi.naver.com/v1/nid/me";
		    //4. apuURL(api 주소)을 저장한다.  
		    
		    URL url = new URL(apiURL);
		    //5. apiURL을 url 객체에 저장한다????
		    		
		    HttpURLConnection con = (HttpURLConnection)url.openConnection();
		    //6. 연결을 오픈한다
		    
		    con.setRequestMethod("GET");
		    //7. 해당 api 서블릿의 get 메소드를 타게 한다
		    		
		    con.setRequestProperty("Authorization", header);
		    //8. Authorization이라는 name에 header를 저장.
		    //프로필 조회 할 때 header가 필요하다. 아래 문서로 확인 가능
		    /*https://developers.naver.com/docs/login/profile/
		 	     기존 REST API처럼 요청 URL과 요청 변수로 호출하는 방법은 동일하나, 
		      OAuth 2.0 인증 기반이므로 추가적으로 네이버 로그인 API를 통해 접근 토큰(access token)을 발급받아, 
		      HTTP로 호출할 때 Header에 접근 토큰 값을 전송해 주시면 활용 가능합니다.
		    
		    */
		    int responseCode = con.getResponseCode();
		    //9. 연결된 것으로부터 코드를 받는다. 
		    
		    BufferedReader br;
		    //여기서부터 통신이 시작된다.
		    if(responseCode==200) 
		    { // 정상 호출
		        br = new BufferedReader(new InputStreamReader(con.getInputStream()));
		    	//10. 상대방으로부터 데이터를 버퍼로 받는다.
		    } 
		    else 
		    {  // 에러 발생
		        br = new BufferedReader(new InputStreamReader(con.getErrorStream()));
		    }
		    String inputLine;
		    StringBuffer res = new StringBuffer();
		    //11. StringBuffer response = new StringBuffer(); 여기서 response가 왜 오류가 났는가?
		    //왜 response가 중복 되었는가
		    //response는 예약어니까 쓰지 못하는거다...
		    
		    while ((inputLine = br.readLine()) != null) {
		    	res.append(inputLine);
		    	//12. 네이버로부터 받은 것을 버퍼에 담고 그걸 한 줄 씩 읽은 다음 inputLine에 넣는다. 그걸 res에 다시 넣는다.
		    	//채팅 할 때처럼 곧바로 출력하는게 아니기 때문에 StringBuffer에 담는다. 어차피 키:밸류 로 되어 있기 때문에 곧바로 출력 하더라도 제대로된 값을 얻기는 힘들다.
		    }
		    //out.print("br을 readLine하여 출력>>>>  "+inputLine);  -> null 나옴
		    
		    br.close();
		    System.out.println(res.toString());
		    
		    //out.print("res를 toString하여 출력>>>>  "+res.toString()+"<br>");
		    //이걸 출력하면 제이슨 타입으로 출력되는 것 같다.
		   
		    //제이슨 파싱 - 오브젝트화 한다.
		    JSONParser parsing = new JSONParser();
		    //13.우선 제이슨 파싱 객체를 받고
		    
		    Object obj = parsing.parse(res.toString()); //오브젝트화 되었다.
		    //14. res를 문자로 바꾼다음 제이슨으로 바꾸고 그걸 오브젝트에 넣고
		    
		    JSONObject jsonobj = (JSONObject) obj;
		    //15. 오브젝트를 제이슨오브젝트로 형변환하고
		    
			 /*  out.print((String)jsonobj.get("response")); //이렇게 하면 ClassCastExeption캐스팅 오류가 뜨면서 출력 안된다
			  	다시 말해, 제이슨오브젝트를 스트링으로 캐스팅 할 수 없다는 거. 
			 	만약에 제이슨오브젝트에서 key value만 있다면 스트링으로 캐스팅 할 수 있지만, value마저도 제이슨이라면 스트링으로 캐스팅 불가능하다
			  	key: value 
			  		key: value  이런 경우
			  */   
		    
		  //출력
		  //out.print(jsonobj.get("response")); 
		     JSONObject responseObj = (JSONObject)jsonobj.get("response");
		 	//16. 제이슨 형변환한 것을 다시 형변환하고
		     String naverName = (String)responseObj.get("name"); //유저 이름
			 String naverId = (String)responseObj.get("id");//30002485 형식의 아이디
			 String naverEmail = (String)responseObj.get("email"); //유저 이메일
			 
			 int a = naverEmail.indexOf('@');
			 String naverUserId = naverEmail.substring(0,a); //유저 아이디
			 
/*			 session.setAttribute("naverName",naverName);
			 session.setAttribute("naverId",naverId);
			 session.setAttribute("naverEmail",naverEmail);
			 session.setAttribute("naverUserId",naverUserId);*/			 
			/*
			naverUserId : zozokjs
			naverEmail : zozokjs@naver.com
			naverId : 30002485
			naverName : 김준성   <- 이런 식으로 출력 됨
					*/
			 System.out.println("*** "+naverId);
			 System.out.println("*** "+naverName);
			 System.out.println("*** "+naverEmail);
			 System.out.println("*** "+naverUserId);
			
			 
			 request.setAttribute("mid", naverId);//1243154형식의 아이디 set된다.
			 request.setAttribute("mname", naverName); //본명
			 request.setAttribute("mgrade", "3"); //구매자 등급으로 고정
			 
			 
			 //id 조회 
			 MemberDAO mdao = MemberDAO.getInstance();
			 String mid = mdao.searchOneId(naverUserId); //DB에서 ID 조회
			 System.out.println("*** "+mid);
			 
			 if(mid == null)//DB에 없는 ID이다(가입 해야 됨)
			 {
				 System.out.println("--확인용-- M_LoginNaverMember.java 분기문 진입(네이버 ID가 DB에 없다)");
				 //DB 객체 얻어옴 -> DB의 메소드 호출하면서 인자로 값 넣어 전달함(가입 완료됨) -> 약관 동의 페이지 출현 -> 로그인 된 메인 페이지
				 mdao.insertNaverMember(naverUserId,naverName,naverEmail); //아이디, 본명, 이메일
				 RequestDispatcher dispatcher = request.getRequestDispatcher("ApiNaver/MarketingAgree.jsp");
				 dispatcher.forward(request,response);	
				 System.out.println("--확인용-- M_LoginNaverMember.java 분기문 통과");
			 }else if(mid.equals(naverId)) //이미 DB에 있는 ID이다(가입된 아이디)
			 {
				 System.out.println("--확인용-- M_LoginNaverMember.java 분기문 진입(네이버 ID가 DB에 이미 있다)");
				 //이미 가입 되어 있는 아이디 입니다. 로그인 해주세요!가 출력 되어야 함
				 //곧바로 로그인 된 메인 페이지로 이동 불가. 페이지가 커져야 함.
				 //그러면 내용 없는 jsp 이동 직후 알림 표시 직후 로그인 페이지 표시
				 response.sendRedirect("MFServlet?command=M_AlertPage");
				 
				 System.out.println("--확인용-- M_LoginNaverMember.java 분기문 통과");
			 
			 }
			 
				 
		    
		} catch (Exception e) {
		    System.out.println(e);
		}	
	}

}
