package com.mf.action.main;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mf.action.Action;

public class M_MsgToManger implements Action {

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String  a = request.getParameter("id");
		String  b = request.getParameter("msg");
		
		System.out.println(a+"여기는" +b+"여기는 어디일까요??????????????");
	}

}
