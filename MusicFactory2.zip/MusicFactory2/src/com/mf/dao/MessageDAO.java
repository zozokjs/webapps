package com.mf.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import com.mf.DBManager.DBManager;
import com.mf.dto.MessageVO;


public class MessageDAO {
	
	public void insertMessage(String mid, String content) {
		String sql = "insert into Message values(Message_seq.nextval, ?, ?, ?)";
		System.out.println("insertMessage 메소드 읽음");
		System.out.println("여기는 insertMessage메소드 mid = "+mid);
		System.out.println("여기는 insertMessage메소드 content = "+content);
		
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		SimpleDateFormat formatter = new SimpleDateFormat ("yyyy-MM-dd hh:mm:ss");
		Calendar cal = Calendar.getInstance();
		String today = null;
		today = formatter.format(cal.getTime());
		Timestamp gdate = Timestamp.valueOf(today);
		
		try {
			conn = DBManager.getConnection();		
			pstmt = conn.prepareStatement(sql); 	
			pstmt.setString(1, mid);
			pstmt.setTimestamp(2, gdate);
			pstmt.setString(3, content);			
			rs = pstmt.executeQuery(); //sql 실행하여 얻은 결과를 rs에 저장한다. 
			System.out.println("--확인용-- insertMessage 메소드 다 읽음");
		} 
		catch(Exception e)
		{
			System.out.println("insertMessage 메소드에서 오류 발생");
			e.printStackTrace();
		}
		finally {
			try {conn.close();} 
			catch (SQLException e) 
			{
				System.out.println("insertMessage 메소드에서 닫기 오류 발생");
				e.printStackTrace();
			}
		}
	}
		
	// 메세지 하나만 가져오는 것.
		public MessageVO selectMessage(String mid) {

			String sql = "select * from Message where mid=?";
			Connection conn = null;
			PreparedStatement pstmt = null;
			ResultSet rs = null;
			MessageVO m = null;
			try {

				// 연결을 얻어온다.
				conn = DBManager.getConnection();
				pstmt = conn.prepareStatement(sql);
				pstmt.setString(1, mid);
				rs = pstmt.executeQuery();

				if (rs.next()) {
					m = new MessageVO();
					m.setGreceiver(rs.getString("greceiver"));
					m.setGdate(rs.getTimestamp("mgdate"));
					m.setGcontent(rs.getString("gcontent"));

				}
			}

			catch (Exception e) {
				System.out.println("selectMessage 메소드에서 오류 발생");
				e.printStackTrace();
			}

			finally {
				try {
					conn.close();
				} catch (SQLException e) {
					System.out.println("selectMessage 메소드에서 닫기 오류 발생");
					e.printStackTrace();
				}
			}

			return m;

		}// 메세지셀렉트 끝
		
		public List<MessageVO> selectOneMessage(String mid){
			System.out.println(mid+""); //2
			String sql = "select * from message where GRECEIVER=?";			
			Connection conn = null;
			PreparedStatement pstmt = null;
			ResultSet rs = null;
			List<MessageVO> arr = new ArrayList<MessageVO>();
			try {

				//연결을 얻어온다.
				conn = DBManager.getConnection();
				pstmt = conn.prepareStatement(sql); 
				pstmt.setString(1, mid); //sql문의 첫번째 ?에 userid를 넣는다. 				
				rs = pstmt.executeQuery(); //sql 실행하여 얻은 결과를 rs에 저장한다.
				
				while(rs.next()) {
					MessageVO m = new MessageVO();
					
					m.setGnumber(rs.getInt("gnumber"));
					m.setGreceiver(rs.getString("greceiver"));				
					m.setGdate(rs.getTimestamp("gdate"));
					m.setGcontent(rs.getString("gcontent"));
					
					
					arr.add(m);
					
					/*pstmt.setInt(1, rs.getInt("gnumber"));	
					pstmt.setString(2, rs.getString("greceiver"));
					pstmt.setTimestamp(3, rs.getTimestamp("gdate"));
					pstmt.setString(4, rs.getString("Gcontent"));*/		
				}
				System.out.println(arr.size() +"여기는 배열의 사이즈를 측정하는 곳입시낟.");
			} 
						
			catch(Exception e)
			{
				System.out.println("selectOneMessage 메소드에서 오류 발생");
				e.printStackTrace();
			}
			
			finally {
				try {conn.close();} 
				catch (SQLException e) 
				{
					System.out.println("selectOneMessage 메소드에서 닫기 오류 발생");
					e.printStackTrace();
				}
			}
			
			return arr;
			
		}//셀렉트1 끝
		
		public MessageVO selectOneMessage2(String mid){
			System.out.println(mid+""); //2
			String sql = "select * from message where gnumber=?";			
			Connection conn = null;
			PreparedStatement pstmt = null;
			ResultSet rs = null;
			MessageVO m = null;
			try {

				//연결을 얻어온다.
				conn = DBManager.getConnection();
				pstmt = conn.prepareStatement(sql); 
				pstmt.setString(1, mid); //sql문의 첫번째 ?에 userid를 넣는다. 				
				rs = pstmt.executeQuery(); //sql 실행하여 얻은 결과를 rs에 저장한다.
				
				if(rs.next()) {
					m = new MessageVO();
					
					m.setGnumber(rs.getInt("gnumber"));
					m.setGreceiver(rs.getString("greceiver"));				
					m.setGdate(rs.getTimestamp("gdate"));
					m.setGcontent(rs.getString("gcontent"));
					
					/*pstmt.setInt(1, rs.getInt("gnumber"));	
					pstmt.setString(2, rs.getString("greceiver"));
					pstmt.setTimestamp(3, rs.getTimestamp("gdate"));
					pstmt.setString(4, rs.getString("Gcontent"));*/		
				}
			} 
						
			catch(Exception e)
			{
				System.out.println("selectOneMessage 메소드에서 오류 발생");
				e.printStackTrace();
			}
			
			finally {
				try {conn.close();} 
				catch (SQLException e) 
				{
					System.out.println("selectOneMessage 메소드에서 닫기 오류 발생");
					e.printStackTrace();
				}
			}
			
			return m;
			
		}//셀렉트2 끝
		
		
		
}