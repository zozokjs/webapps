package com.mf.dto;

public class UserVo {
	String Pname;
	int Pprice;
	String Pjanre;
	String Pauthor;
	String ad;
	int Pnumber;
	
	

	public int getPnumber() {
		return Pnumber;
	}
	public void setPnumber(int pnumber) {
		Pnumber = pnumber;
	}
	public String getAd() {
		return ad;
	}
	public void setAd(String ad) {
		this.ad = ad;
	}
	public String getPname() {
		return Pname;
	}
	public void setPname(String pname) {
		Pname = pname;
	}
	public int getPprice() {
		return Pprice;
	}
	public void setPprice(int pprice) {
		Pprice = pprice;
	}
	public String getPjanre() {
		return Pjanre;
	}
	public void setPjanre(String pjanre) {
		Pjanre = pjanre;
	}
	public String getPauthor() {
		return Pauthor;
	}
	public void setPauthor(String pauthor) {
		Pauthor = pauthor;
	}
	
	
}
