package com.mf.dto;
//미사용
import java.sql.Timestamp;

public class MessageVO {
	private int gnumber;
	private String greceiver; //
	private Timestamp gdate;
	private String gcontent;
	
	
	public int getGnumber() {
		return gnumber;
	}
	public void setGnumber(int gnumber) {
		this.gnumber = gnumber;
	}
	public String getGreceiver() {
		return greceiver;
	}
	public void setGreceiver(String greceiver) {
		this.greceiver = greceiver;
	}
	public Timestamp getGdate() {
		return gdate;
	}
	public void setGdate(Timestamp gdate) {
		this.gdate = gdate;
	}
	public String getGcontent() {
		return gcontent;
	}
	public void setGcontent(String gcontent) {
		this.gcontent = gcontent;
	}
	
	
	
	
}
