create table member(
    mid varchar2(50) not null,
    mpwd varchar2(50) not null,
    mname varchar2(50) not null,
    mbirth date,
    memail varchar2(50),
    mphone varchar2(50),
    maddr varchar2(200),
    mjanre varchar2(50),
    mgrade number not null,
    mopnum number,
    mwarning number
); --성공

alter table member add constraint member_pk primary key(mid); --pk 설정

create table product(
    pnumber number not null,
    pname varchar2(50) not null,
    pdate date,
    ppicture varchar2(50),
    pscore number,
    pprice number not null,
    pjanre varchar2(50),
    pauthor varchar2(50),
    mid varchar2(50) not null,
    pamount number
);

alter table product add constraint product_pk primary key(pnumber); --pk 설정

alter table product add constraint product_fk1 foreign key(mid) references member(mid); --fk 설정

create sequence product_seq start with 1 increment by 1; --시퀸스 생성

insert into member values('1','1','first','18/01/01','first@naver.com',01012345678,'here','dance',1,0,0);
insert into member values('2','2','second','18/02/01','second@naver.com',01012345678,'there','rock',2,0,0);
insert into member values('3','3','third','18/03/01','third@naver.com',01012345678,'where','ballad',3,0,0);
insert into member values('22','22','ss','18/02/02','ss@naver.com',01012345678,'there','rock',2,0,0);
insert into member values('33','33','tt','18/03/01','tt@naver.com',01012345678,'where','ballad',3,0,0);

insert into product values(1,'first music','18/01/01','1.png',5,1000,'rock','first author', 2,0);
insert into product values(2,'second music','18/02/02','2.png',5,2000,'ballad','second author', 2,0);
insert into product values(3,'third music','18/03/03','3.png',5,3000,'hiphop','third author', 2,0);
insert into product values(4,'4 music','18/03/03','4.png',5,1000,'ballad','4 author', 22,0);
insert into product values(5,'5 music','18/03/03','5.png',5,2000,'ballad','5 author', 22,0);
insert into product values(6,'6 music','18/03/03','6.png',5,9000,'ballad','6 author', 22,0);
insert into product values(7,'7 music','18/03/03','7.png',5,300,'ballad','7 author', 2,0);



create table ordering(
    mid varchar2(50) not null,
    pnumber number not null,
    ovolume number not null,
    onumber  number not null,
    otf number   
);

alter table ordering add constraint ordering_pk primary key(onumber); --pk 설정

alter table ordering add constraint ordering_fk1_mid foreign key(mid) references member(mid); --fk 설정
alter table ordering add constraint ordering_fk1_pnumber foreign key(pnumber) 
references product(pnumber);--fk 설정

create sequence ordering_seq start with 1 increment by 1; --시퀸스 생성

commit;