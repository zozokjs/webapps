/**
 * 
 */
function loginCheck()
{	
	if(document.frm2.mid.value.length == 0)
	{
		alert("아이디를 입력해야 합니다");
		frm2.mid.focus();
		return false;
	}
	if(document.frm2.mpwd.value.length == "")
	{
		alert("비밀번호를 입력해야 합니다");
		frm2.mpwd.focus();
		return false;
	}
	return true;
}

function test()
{	
	alert('test');
	
}