package com.mf.dto;

import java.sql.Timestamp;
//////////////Product 테이블과 Ordering 테이블 조인을 위해 필요함


public class PandOVO {

	private int pnumber; //상품 번호
	private String mid; //구매자 아이디
	private int ovolume; // 구매 수량
	private int onumber;//구매 혹은 장바구니 번호
	private int otf; //구매 전후 파악 위해 사용. 0이면 구매 전. 1이면 구매 후(결제 후) 
		
	private String pname; //제품 제목	
	private Timestamp pdate; //제품 게시 날짜	
	private String ppicture; //첨부한 그림	
	private int pscore; //제품에 대한 평점
	private int pprice; //제품 가격	
	private String pjanre; //제품 장르
	private String pauthor; //제품 제작자	
	private int pamount; //제품 수량
	
	public int getPnumber() {
		return pnumber;
	}

	public void setPnumber(int pnumber) {
		this.pnumber = pnumber;
	}

	public String getMid() {
		return mid;
	}

	public void setMid(String mid) {
		this.mid = mid;
	}

	public int getOvolume() {
		return ovolume;
	}

	public void setOvolume(int ovolume) {
		this.ovolume = ovolume;
	}

	public int getOnumber() {
		return onumber;
	}

	public void setOnumber(int onumber) {
		this.onumber = onumber;
	}

	public int getOtf() {
		return otf;
	}

	public void setOtf(int otf) {
		this.otf = otf;
	}

	public String getPname() {
		return pname;
	}

	public void setPname(String pname) {
		this.pname = pname;
	}

	public Timestamp getPdate() {
		return pdate;
	}

	public void setPdate(Timestamp pdate) {
		this.pdate = pdate;
	}

	public String getPpicture() {
		return ppicture;
	}

	public void setPpicture(String ppicture) {
		this.ppicture = ppicture;
	}

	public int getPscore() {
		return pscore;
	}

	public void setPscore(int pscore) {
		this.pscore = pscore;
	}

	public int getPprice() {
		return pprice;
	}

	public void setPprice(int pprice) {
		this.pprice = pprice;
	}

	public String getPjanre() {
		return pjanre;
	}

	public void setPjanre(String pjanre) {
		this.pjanre = pjanre;
	}

	public String getPauthor() {
		return pauthor;
	}

	public void setPauthor(String pauthor) {
		this.pauthor = pauthor;
	}

	public int getPamount() {
		return pamount;
	}

	public void setPamount(int pamount) {
		this.pamount = pamount;
	}
	
	
	
}
