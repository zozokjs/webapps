package com.mf.dto;

public class OrderingVO {

	private int pnumber; //상품 번호
	private String mid; //구매자 아이디
	private int ovolume; // 구매 수량
	private int onumber;//구매 혹은 장바구니 번호
	private int otf; //구매 전후 파악 위해 사용. 0이면 구매 전. 1이면 구매 후(결제 후) 
	
	
	
	public int getOnumber() {
		return onumber;
	}
	public void setOnumber(int onumber) {
		this.onumber = onumber;
	}
	public int getOtf() {
		return otf;
	}
	public void setOtf(int otf) {
		this.otf = otf;
	}
	public int getPnumber() {
		return pnumber;
	}
	public void setPnumber(int pnumber) {
		this.pnumber = pnumber;
	}
	public String getMid() {
		return mid;
	}
	public void setMid(String mid) {
		this.mid = mid;
	}
	public int getOvolume() {
		return ovolume;
	}
	public void setOvolume(int ovolume) {
		this.ovolume = ovolume;
	}
	
	
}
