package com.mf.controller;

import java.io.IOException;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.jsp.PageContext;
import javax.websocket.Session;

import com.mf.action.Action;
import com.mf.dto.ProductVO;
import com.oreilly.servlet.MultipartRequest;
import com.oreilly.servlet.multipart.DefaultFileRenamePolicy;


@WebServlet("/BServlet")
public class BServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
  
    public BServlet() {
        super();
  
    }


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		System.out.println("--확인용-- 여기는 BServlet의 doGet 메소드");
		
		String command = (String)request.getAttribute("command");
		System.out.println("입력한 command>> "+command);
		
		ActionFactory af = ActionFactory.getInstance();	
		Action action = af.getAction(command);
		
		action.execute(request, response);
		
		System.out.println("Bservlet의 doGet 메소드 다 읽음");
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			
		System.out.println("--확인용-- 여기는 Bservlet의 doPost 메소드");
		
		
			request.setCharacterEncoding("UTF-8");		
			//	ServletContext context  = getServletContext();	이건 서블릿에서만 쓸 수 잇는 것 같은데
			// 이렇게하면 로그인 조회 할 때 오류 뜬다. 무조건 post로 타기 때문인데 여기서 분기 할 수 있는 방법이 있나?
			// 혹은 또 다른 서블릿을 타게 해야 한다.
			
			//파일 저장을 위해 넘김.
		
			ServletContext context  = getServletContext();	
			//context에 저장된 건 실제 .메타데이터에 있는 폴더다. 리억 패스
			String path = context.getRealPath("uploadFile");
			
			System.out.println("서버 컨택스트 패스:   "+context);
			//출력됨:  org.apache.catalina.core.ApplicationContextFacade@410be27d
					
			System.out.println("리얼 컨텍스트 패스:   "+path);
			//출력됨:  D:\jsp_lec\.메타데이터\.플러그인즈\org.eclipse.wst.server.core\tmp0\더블유티피웹엡스\업로드\업로드
					
			String encType = "UTF-8";
			int sizeLimit = 1024*1024*20; //업로드 사이즈 지정
		
			MultipartRequest multi = new MultipartRequest(
					  request, 
				   	  path, 
				 	  sizeLimit, 
					  encType, 
					  new DefaultFileRenamePolicy()
					 );//이게 실행될때 이미지는 메타데이터에 저장된다.
			
			HttpSession ses = request.getSession(); //세션에 저장된 것에서 가져온다. 
			String mid = (String)ses.getAttribute("mid");
					
			int pamount = Integer.parseInt(multi.getParameter("pamount"));		
			
			String command = multi.getParameter("command");
			String pname = multi.getParameter("pname");
			int pprice= Integer.parseInt(multi.getParameter("pprice"));
			String pjanre = multi.getParameter("pjanre");
			String pauthor = multi.getParameter("pauthor");	
			String ppicture = multi.getFilesystemName("ppicture");
			//String mid = multi.getParameter("mid"); 	
			int pscore = Integer.parseInt(multi.getParameter("pscore"));
			int pnumber = 0;
			
			if(multi.getParameter("pnumber")==null)
			{
				
			}else
			{
				pnumber = Integer.parseInt(multi.getParameter("pnumber"));
			}
				
			request.setAttribute("command", command);
				
			SimpleDateFormat formatter = new SimpleDateFormat ("yyyy-MM-dd hh:mm:ss");
			Calendar cal = Calendar.getInstance();
			String today = null;
			today = formatter.format(cal.getTime());
			Timestamp pdate = Timestamp.valueOf(today);
			
			
						
			ProductVO product = new ProductVO();
			
			product.setPamount(pamount);
			
			product.setPnumber(pnumber);
			
			
			product.setPdate(pdate);
			product.setPname(pname);
			product.setPjanre(pjanre);
			product.setPprice(pprice);
			product.setPscore(pscore);
			product.setMid(mid);
			product.setPauthor(pauthor);
			product.setPpicture(ppicture);
			
			request.setAttribute("product", product);
			
			doGet(request, response);
			
			System.out.println("Bservlet의 doPost 메소드 다 읽음");
	}

}
