package com.mf.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.mf.DBManager.DBManager;
import com.mf.dto.ProductVO;
import com.mf.dto.MemberVO;

public class ProductDAO 
{
	
	private ProductDAO() {}
	
	private static ProductDAO instance = new ProductDAO();
	
	public static ProductDAO getInstance()
	{
		return instance;
	}
	
	public void insertProduct(ProductVO po) //회원가입 jsp페이지에서 하여튼 뭔가 회원가입정보를 통째로 받아옴
	{
		
		//bnumber, btitle, bcontent, bdate, bpicture, bscore, bprice, bjanre, bauthor, bdate, mid
		String sql 
		= "insert into product(pnumber, pname, pdate, ppicture, pscore, pprice, pjanre, pauthor, mid,pamount) "
				+ "values (product_seq.nextval,?,?,?,?,?,?,?,?,?)";
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			conn = DBManager.getConnection();
			pstmt = conn.prepareStatement(sql); 
			pstmt.setString(1, po.getPname());
			pstmt.setTimestamp(2, po.getPdate());
			pstmt.setString(3, po.getPpicture());
			pstmt.setInt(4, po.getPscore());
			pstmt.setInt(5, po.getPprice());
			pstmt.setString(6, po.getPjanre());
			pstmt.setString(7, po.getPauthor());
			pstmt.setString(8, po.getMid());
			pstmt.setInt(9, po.getPamount());
			
			rs = pstmt.executeQuery(); //sql 실행하여 얻은 결과를 rs에 저장한다. 
			System.out.println("확인용// insertProduct 메소드 다 읽음");
		} 
		catch(Exception e)
		{
			System.out.println("insertProduct 메소드에서 오류 발생");
			e.printStackTrace();
		}
		finally {
			try {conn.close();} 
			catch (SQLException e) 
			{
				System.out.println("insertProduct 메소드에서 닫기 오류 발생");
				e.printStackTrace();
			}
		}
		
		
	}
	
	
	public List<ProductVO> selectAllBySeller(String mid){
		String sql = "select * from product where mid = "+ mid;			
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		List<ProductVO> arr = new ArrayList<ProductVO>();		
		
		try {			
			//연결을 얻어온다.
			conn = DBManager.getConnection();
			pstmt = conn.prepareStatement(sql); 
			//pstmt.setString(1, mid);
			rs = pstmt.executeQuery(); //sql 실행하여 얻은 결과를 rs에 저장한다. 
			
			while(rs.next()) 
			{
				ProductVO b = new ProductVO();		
				b.setPnumber(rs.getInt("pnumber"));
				b.setPname(rs.getString("pname"));	
				b.setPpicture(rs.getString("ppicture"));
				b.setMid(rs.getString("mid"));
				b.setPscore(rs.getInt("pscore"));
				b.setPprice(rs.getInt("pprice"));
				b.setPjanre(rs.getString("pjanre"));
				b.setPauthor(rs.getString("pauthor"));
				arr.add(b);
			}
		} 
		
			
		catch(Exception e)
		{
			System.out.println("selectAllBySeller 메소드에서 오류 발생");
			e.printStackTrace();
		}
		
		finally {
			try {conn.close();} 
			catch (SQLException e) 
			{
				System.out.println("selectAllBySeller 메소드에서 닫기 오류 발생");
				e.printStackTrace();
			}
		}
			
		return arr;	
		
	}
	
	
	public List<ProductVO> selectAllByDate(){
		String sql = "select * from product order by pdate desc";	
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		List<ProductVO> arr = new ArrayList<ProductVO>();		
		
		try {			
			//연결을 얻어온다.
			conn = DBManager.getConnection();
			pstmt = conn.prepareStatement(sql); 
			//pstmt.setString(1, mid);
			rs = pstmt.executeQuery(); //sql 실행하여 얻은 결과를 rs에 저장한다. 
			
			while(rs.next()) 
			{
				ProductVO p = new ProductVO();	
				p.setPnumber(rs.getInt("pnumber"));
				p.setPname(rs.getString("pname"));	
				p.setPpicture(rs.getString("ppicture"));
				p.setMid(rs.getString("mid"));
				p.setPscore(rs.getInt("pscore"));
				p.setPprice(rs.getInt("pprice"));
				p.setPjanre(rs.getString("pjanre"));
				p.setPauthor(rs.getString("pauthor"));
				arr.add(p);
			}
		} 
		
			
		catch(Exception e)
		{
			System.out.println("selectAllBySeller 메소드에서 오류 발생");
			e.printStackTrace();
		}
		
		finally {
			try {conn.close();} 
			catch (SQLException e) 
			{
				System.out.println("selectAllBySeller 메소드에서 닫기 오류 발생");
				e.printStackTrace();
			}
		}
			
		return arr;	
		
	}
	
	public ProductVO selectOneProduct(int pnumber){
		String sql = "select * from Product where pnumber = ?";	
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		ProductVO b = new ProductVO();		
		try {			
			
			conn = DBManager.getConnection();
			pstmt = conn.prepareStatement(sql); 
			pstmt.setInt(1, pnumber);
			rs = pstmt.executeQuery(); 
			
			if(rs.next()) 
			{
				b.setPnumber(rs.getInt("pnumber"));		
				b.setPname(rs.getString("pname"));	
				b.setPpicture(rs.getString("ppicture"));
				b.setMid(rs.getString("mid"));
				b.setPscore(rs.getInt("pscore"));
				b.setPprice(rs.getInt("pprice"));
				b.setPjanre(rs.getString("pjanre"));
				b.setPauthor(rs.getString("pauthor"));
				b.setPdate(rs.getTimestamp("pdate"));
				
			}
		} 
					
		catch(Exception e)
		{
			System.out.println("selectOneProduct 메소드에서 오류 발생");
			e.printStackTrace();
		}
		
		finally {
			try {conn.close();} 
			catch (SQLException e) 
			{
				System.out.println("selectOneProduct 메소드에서 닫기 오류 발생");
				e.printStackTrace();
			}
		}
			
		return b;
		
	}//셀렉트1 끝

	public void updateProduct(ProductVO po) 
	{					
		int pnumber = po.getPnumber();
		String sql = "update product set pname = ?, pdate =?, ppicture =?, "
						+ "pscore =?, pprice=?, pjanre=?, pauthor=?, pamount=? where pnumber = "+pnumber;
		Connection conn = null;
		PreparedStatement pstmt = null;
				
		try {
			conn = DBManager.getConnection();
			pstmt = conn.prepareStatement(sql); 
			pstmt.setString(1, po.getPname());
			pstmt.setTimestamp(2, po.getPdate());
			pstmt.setString(3, po.getPpicture());
			pstmt.setInt(4, po.getPscore());
			pstmt.setInt(5, po.getPprice());
			pstmt.setString(6, po.getPjanre());
			pstmt.setString(7, po.getPauthor());	
			pstmt.setInt(8, po.getPamount());	
			
			pstmt.executeUpdate();
			System.out.println("updateProduct 메소드 다 읽음");
		} 
		catch(Exception e)
		{
			System.out.println("updateProduct 메소드에서 오류 발생");
			e.printStackTrace();
		}
		finally {
			try {conn.close();} 
			catch (SQLException e) 
			{
				System.out.println("updateProduct 메소드에서 닫기 오류 발생");
				e.printStackTrace();
			}
		}
	}
	
	public void DeleteProduct(int pnumber) 
	{
		String sql = "delete Product where pnumber ="+pnumber;
		Connection conn = null;
		PreparedStatement pstmt = null;
		{
			
			try {
				conn = DBManager.getConnection();
				pstmt = conn.prepareStatement(sql);
				pstmt.executeUpdate();
				System.out.println("DeleteProduct 메소드 다 읽음");
				
				
			} catch (SQLException e) {
				System.out.println("DeleteProduct 메소드에서 오류 발생");
				e.printStackTrace();
			} 
			finally {
				try {conn.close();} 
				catch (SQLException e) 
				{
					System.out.println("DeleteProduct 메소드에서 닫기 오류 발생");
					e.printStackTrace();
				}
			}		
		}	
	}

	public List<ProductVO> selectCategory(String pjanre) {
		
		
		String sql = "select * from product where pjanre ='"+pjanre+"'";
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;	
		List<ProductVO> arr = new ArrayList<ProductVO>();	
		try {			
			
			conn = DBManager.getConnection();
			pstmt = conn.prepareStatement(sql); 
			rs = pstmt.executeQuery(); 
			
			while(rs.next()) 
			{
				ProductVO b = new ProductVO();
				b.setPnumber(rs.getInt("pnumber"));		
				b.setPname(rs.getString("pname"));	
				b.setPpicture(rs.getString("ppicture"));
				b.setMid(rs.getString("mid"));
				b.setPscore(rs.getInt("pscore"));
				b.setPprice(rs.getInt("pprice"));
				b.setPjanre(rs.getString("pjanre"));
				b.setPauthor(rs.getString("pauthor"));
				b.setPdate(rs.getTimestamp("pdate"));
				arr.add(b);
			}
		} 
					
		catch(Exception e)
		{
			System.out.println("SelectCategory 메소드에서 오류 발생");
			e.printStackTrace();
		}
		
		finally {
			try {conn.close();} 
			catch (SQLException e) 
			{
				System.out.println("SelectCategory 메소드에서 닫기 오류 발생");
				e.printStackTrace();
			}
		}
			
		return arr;
		
		
		
	}

	public List<ProductVO> searchSys(String searchSelect, String searchWord) {
		String sql = "select * from product where "+searchSelect+"= '"+searchWord+"' ";
		
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;	
		List<ProductVO> arr = new ArrayList<ProductVO>();	
		try {			
			
			conn = DBManager.getConnection();
			pstmt = conn.prepareStatement(sql); 
			rs = pstmt.executeQuery(); 
			
			while(rs.next()) 
			{
				ProductVO b = new ProductVO();
				b.setPnumber(rs.getInt("pnumber"));		
				b.setPname(rs.getString("pname"));	
				b.setPpicture(rs.getString("ppicture"));
				b.setMid(rs.getString("mid"));
				b.setPscore(rs.getInt("pscore"));
				b.setPprice(rs.getInt("pprice"));
				b.setPjanre(rs.getString("pjanre"));
				b.setPauthor(rs.getString("pauthor"));
				b.setPdate(rs.getTimestamp("pdate"));
				arr.add(b);
			}
		} 
					
		catch(Exception e)
		{
			System.out.println("searchSys 메소드에서 오류 발생");
			e.printStackTrace();
		}
		
		finally {
			try {conn.close();} 
			catch (SQLException e) 
			{
				System.out.println("searchSys 메소드에서 닫기 오류 발생");
				e.printStackTrace();
			}
		}
			
		return arr;
	}
	
		
		
		
	
	
	
	
	
	
	
	
	
	
}
