package com.mf.action.main;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mf.action.Action;
import com.mf.dao.ProductDAO;
import com.mf.dto.ProductVO;

public class MainPage implements Action 
{

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("MainPage.java 진입");
		
		ProductDAO bDao = ProductDAO.getInstance();
		List<ProductVO> Productlist = bDao.selectAllByDate(); 
		
		request.setAttribute("Productlist", Productlist);
		
		RequestDispatcher dispatcher = request.getRequestDispatcher("Main/MainPage.jsp");
		//상대 경로 사용
		dispatcher.forward(request, response);
		//메인 페이지에 최근에 올라온 상품 정보가 전달 됨
		
		System.out.println("MainPage.java 통과");
	}

}
