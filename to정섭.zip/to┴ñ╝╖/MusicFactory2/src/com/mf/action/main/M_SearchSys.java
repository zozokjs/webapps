package com.mf.action.main;


import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mf.action.Action;
import com.mf.dao.ProductDAO;
import com.mf.dto.ProductVO;

public class M_SearchSys implements Action{

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("--확인용-- M_SearchSys.java 진입");
		String searchSelect=  request.getParameter("searchSelect"); //선택한 범주. 상품명? 아티스트명?
		String searchWord = request.getParameter("searchWord"); //입력한 단어
		
		
		ProductDAO pdao = ProductDAO.getInstance();
		List<ProductVO> product = pdao.searchSys(searchSelect,searchWord);
		
		
		request.setAttribute("product", product);
		request.setAttribute("searchSelect", searchSelect);
		request.setAttribute("searchWord", searchWord);
		
		
		
		RequestDispatcher dis = request.getRequestDispatcher("Main/M_MainCategorySelect.jsp");
		dis.forward(request, response);
		
		System.out.println("M_SearchSys.java 통과");
		
	}

}
