package com.mf.action.member;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.mf.action.Action;
import com.mf.dao.MemberDAO;
import com.mf.dao.ProductDAO;
import com.mf.dto.ProductVO;
import com.mf.dto.MemberVO;

public class M_LoginMember implements Action
{
	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("--확인용-- M_LoginMember.java 진입");
		
		String mid = request.getParameter("mid");
		String mpwd = request.getParameter("mpwd");
		
		
		//화면에 로그인한 멤버의 id,pwd,mgrade 정보 출력
		MemberDAO mdao = MemberDAO.getInstance();		
		MemberVO member = mdao.selectOneMember(mid);	
		String mpwd2 = member.getMpwd(); //DB에 저장된 사용자의 pwd 조회	
		request.setAttribute("mid",member.getMid());
		request.setAttribute("mname",member.getMname());
		request.setAttribute("mgrade",member.getMgrade());	
		request.setAttribute("mopnum",member.getMopnum());	
		
		//화면에 로그인한 멤버의 id,pwd,mgrade 정보 출력
		
		
		//화면에 최근 등록 상품 출력
		ProductDAO pdao = ProductDAO.getInstance();
		List<ProductVO> Productlist = pdao.selectAllByDate();
		request.setAttribute("Productlist", Productlist);
		//화면에 최근 등록 상품 출력
		
		if(mpwd.equals(mpwd2))
			//사용자가 입력한 비번과 db 조회를 통한 비번이 일치한다면,
		{
			
			System.out.println("--확인용-- 여기는 M_LoginMember의 execute");
			System.out.println("--로그인 정보 일치!--");
			RequestDispatcher dispatcher = request.getRequestDispatcher("Main/MainPage2.jsp");
			dispatcher.forward(request,response);	
			
		}
		else
		{
			System.out.println("--확인용-- 여기는 M_LoginMember의 execute");		
			System.out.println("--로그인 정보 틀림!--");
			response.sendRedirect("MFServlet?command=MainPage");
			//이렇게 서블릿을 통과해야만 최근 등록된 상품을 실시간으로 적용 받아 화면에 출력 할 수 있다.
			
		}
		System.out.println("--확인용-- M_LoginMember.java 다 읽음");
		
	}

}
