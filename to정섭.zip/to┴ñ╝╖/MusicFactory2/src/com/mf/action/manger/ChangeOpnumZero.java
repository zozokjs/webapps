package com.mf.action.manger;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mf.action.Action;
import com.mf.dao.MemberDAO;
import com.mf.dto.MemberVO;

public class ChangeOpnumZero implements Action
{

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("--확인용-- ChangeOpnumZero 진입");
		
		String mid = request.getParameter("mid");
		
		MemberDAO mdao = MemberDAO.getInstance();
		mdao.changeOpnumZero(mid);	
		List<MemberVO> member = mdao.selectByGradeMember(2); //판매자 등급이 2
	
		request.setAttribute("member", member);
		
		RequestDispatcher dispatcher = request.getRequestDispatcher("Boss/manageMain.jsp");
		dispatcher.forward(request, response);
		
		System.out.println("ChangeOpnumZero 다 읽음");
		
	}

}
