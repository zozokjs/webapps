package com.mf.action.seller;

import java.io.IOException;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mf.action.Action;
import com.mf.dao.ProductDAO;
import com.mf.dto.ProductVO;
import com.oreilly.servlet.MultipartRequest;
import com.oreilly.servlet.multipart.DefaultFileRenamePolicy;
//판매자가 제품을 등록할때 사용. sellerInsert에서 넘어

public class S_SellerProductInsert implements Action
{

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("--확인용-- 여기는 S_SellerProductInsert ");
		
		ProductVO po = (ProductVO)request.getAttribute("product");
		ProductDAO pDao =ProductDAO.getInstance();
		pDao.insertProduct(po);
	
		//String btitle = (String)request.getAttribute("btitle");
		//String mid = (String)request.getAttribute("mid");		
			
		RequestDispatcher dispatcher = request.getRequestDispatcher("MFServlet?command=S_SellerMain");
		dispatcher.forward(request, response);

		System.out.println("--확인용-- S_SellerProductInsert 다 읽음");
	}

}
