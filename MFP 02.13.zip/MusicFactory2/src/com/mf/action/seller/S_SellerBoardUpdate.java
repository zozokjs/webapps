package com.mf.action.seller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mf.action.Action;
import com.mf.dao.BoardDAO;
import com.mf.dto.BoardVO;

public class S_SellerBoardUpdate implements Action{

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		System.out.println("--확인용-- 여기는 S_SellerBoardUpdate");
		BoardVO vo = (BoardVO)request.getAttribute("board");
		BoardDAO bdao = BoardDAO.getInstance();
		bdao.updateBoard(vo);
		
		int bnumber = vo.getBnumber();
		System.out.println("bnumber>>>>>>>>>>>>>>>>>>>  "+bnumber);
		//request.setAttribute("bnumber", bnumber);
		
		RequestDispatcher dispatcher = request.getRequestDispatcher("MFServlet?command=S_SellerBoardDetail&bnumber="+bnumber);
		dispatcher.forward(request, response);
		System.out.println("S_SellerBoardUpdate 다 읽음");
		
	}

}
