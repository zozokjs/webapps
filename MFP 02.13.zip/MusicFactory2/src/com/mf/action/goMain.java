package com.mf.action;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.mf.dao.BoardDAO;
import com.mf.dto.BoardVO;

public class goMain implements Action
{

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
	/*	HttpSession session = request.getSession();
		
		String mid = (String) request.getAttribute("mid");
		session.getAttribute("mid")
		
		String name = (String) request.getAttribute("mname");
		session.setAttribute("name", name);
		
		*/
		
		BoardDAO dao = BoardDAO.getInstance();
		List<BoardVO> board = dao.selectAllByDate();
		
		request.setAttribute("board", board);
		
		RequestDispatcher dispatcher = request.getRequestDispatcher("Main/MainPage.jsp");
		dispatcher.forward(request, response);
		

		
		
	
	}

}
