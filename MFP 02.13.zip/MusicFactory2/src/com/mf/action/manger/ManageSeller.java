package com.mf.action.manger;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mf.action.Action;
import com.mf.dao.BoardDAO;
import com.mf.dao.MemberDAO;
import com.mf.dto.BoardVO;
import com.mf.dto.MemberVO;

public class ManageSeller implements Action{
	//manageSeller 로 가는 액션(판매자 상세보기)
	//필요한 것 -> 셀러 한명의 정보와 셀러의 게시글 정보
	//(아직 액션팩토리에 들어가있지않음)
	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
		
		System.out.println("--확인용-- ManageSeller 진입");
		String mid = request.getParameter("mid");
		
		MemberDAO mDao = MemberDAO.getInstance();
		BoardDAO bDao = BoardDAO.getInstance();
					
		MemberVO m = mDao.selectOneMember(mid);
		
		List<BoardVO> b = bDao.selectAllBySeller(mid);
		if (m== null) {
			System.out.println("못받아옴 : m is null");
		}
		request.setAttribute("member", m);
		request.setAttribute("board", b);
				
		RequestDispatcher dispatcher = request.getRequestDispatcher("Boss/manageSeller.jsp");
		dispatcher.forward(request, response);
		
		System.out.println("ManageSeller 다 읽음");
		
	}
}
