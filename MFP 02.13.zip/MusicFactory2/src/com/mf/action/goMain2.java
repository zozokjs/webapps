package com.mf.action;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.mf.dao.BoardDAO;
import com.mf.dto.BoardVO;

public class goMain2 implements Action
{

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		HttpSession session = request.getSession();
		String mid=(String) session.getAttribute("mid"); //아이디 넘어오는거 확인.
		request.setAttribute("mid", mid);		
		
		BoardDAO dao = BoardDAO.getInstance();
		List<BoardVO> board = dao.selectAllByDate();
		
		request.setAttribute("board", board);
		
		RequestDispatcher dispatcher = request.getRequestDispatcher("Main/MainPage2.jsp");
		dispatcher.forward(request, response);
		

	
	}

}
