package com.mf.controller;

import java.io.IOException;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.mf.action.Action;
import com.oreilly.servlet.MultipartRequest;
import com.oreilly.servlet.multipart.DefaultFileRenamePolicy;



@WebServlet("/MFServlet")
public class MFServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
    public MFServlet() {
        super();
       
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("--확인용-- 여기는 MFServlet");
		String command = request.getParameter("command");
		System.out.println("--확인용-- MFServlet으로 전달된 command >> "+command);
		
				
		ActionFactory af = ActionFactory.getInstance();
		Action action = af.getAction(command);
		
		action.execute(request, response);
		
		
		
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
				request.setCharacterEncoding("UTF-8");	
				doGet(request, response);
	}

}
