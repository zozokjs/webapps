package com.mf.dto;

import java.sql.Timestamp;

public class BoardVO {
	
	private int bnumber; //게시글(제품) 번호.. 만약 DB에 시퀸스 넣었다면 주석 처리 해야함
		
	private String btitle; //게시글 제목
	
	private String bcontent; //게시글 내용
	
	private Timestamp bdate; //게시 날짜.. 만약 DB 추가시 자동으로 넣는거라면 주석 처리 해야함
	
	private String bpicture; //첨부한 그림
	
	private String mid; //해당 게시글을 쓴 아이디(참조).. 아이디를 만약 session에서 얻어온다면 여기에 세팅하는게 옳은건가?
	
	private int bscore; //게시글에 대한 평점
	private int bprice; //게시글에 대한 가격
	
	private String bjanre; //DB에 등록 안 됨(get,set추가함)
	private String bauthor; //DB에 등록 안 됨(get,set추가함)
	
	public int getBnumber() {
		return bnumber;
	}
	public void setBnumber(int bnumber) {
		this.bnumber = bnumber;
	}
	
	
	public Timestamp getBdate() {
		return bdate;
	}
	public void setBdate(Timestamp bdate) {
		this.bdate = bdate;
	}
		
	
	public String getMid() {
		return mid;
	}
	public void setMid(String mid) {
		this.mid = mid;
	}
	
	
	public int getBprice() {
		return bprice;
	}
	public void setBprice(int bprice) {
		this.bprice = bprice;
	}
	public String getBjanre() {
		return bjanre;
	}
	public void setBjanre(String bjanre) {
		this.bjanre = bjanre;
	}
	public String getBauthor() {
		return bauthor;
	}
	public void setBauthor(String bauthor) {
		this.bauthor = bauthor;
	}
	

	
	public String getBtitle() {
		return btitle;
	}
	public void setBtitle(String btitle) {
		this.btitle = btitle;
	}
	public String getBcontent() {
		return bcontent;
	}
	public void setBcontent(String bcontent) {
		this.bcontent = bcontent;
	}

	public String getBpicture() {
		return bpicture;
	}
	public void setBpicture(String bpicture) {
		this.bpicture = bpicture;
	}

	public int getBscore() {
		return bscore;
	}
	public void setBscore(int bscore) {
		this.bscore = bscore;
	}
	
	
	
}
