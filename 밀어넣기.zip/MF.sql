create table member(
    mid varchar2(50) not null,
    mpwd varchar2(50) not null,
    mname varchar2(50) not null,
    mbirth date,
    memail varchar2(50),
    mphone varchar2(50),
    maddr varchar2(200),
    mjanre varchar2(50),
    mgrade number not null,
    mopnum number,
    mwarning number
); --성공

alter table member add constraint member_pk primary key(mid); --pk 설정

create table board(
    bnumber number not null,
    btitle varchar2(50) not null,
    bcontent varchar2(2000),
    bdate date,
    bpicture varchar2(50),
    bscore number,
    bprice number not null,
    bjanre varchar2(50),
    bauthor varchar2(50),
    mid varchar2(50) not null
);

alter table board add constraint board_pk primary key(bnumber); --pk 설정

alter table board add constraint board_fk1 foreign key(mid) references member(mid); --fk 설정

create sequence board_seq start with 1 increment by 1; --시퀸스 생성

insert into member values('1','1','first','18/01/01','first@naver.com',01012345678,'here','dance',1,0,0);
insert into member values('2','2','second','18/02/01','second@naver.com',01012345678,'there','rock',2,0,0);
insert into member values('3','3','third','18/03/01','third@naver.com',01012345678,'where','ballad',3,0,0);
insert into member values('22','22','ss','18/02/02','ss@naver.com',01012345678,'there','rock',2,0,0);
insert into member values('33','33','tt','18/03/01','tt@naver.com',01012345678,'where','ballad',3,0,0);

insert into board values(1,'first music','냉무','18/01/01','1.png',5,1000,'rock','first author', 2);
insert into board values(2,'second music','냉무','18/02/02','2.png',5,2000,'ballad','second author', 2);
insert into board values(3,'third music','냉무','18/03/03','3.png',5,3000,'hiphop','third author', 2);

commit;