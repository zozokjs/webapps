package com.mf.action.manger;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mf.action.Action;
import com.mf.dao.MessageDAO;
import com.mf.dto.MemberVO;
import com.mf.dto.MessageVO;

public class getMessage implements Action {
	//(아직 액션팩토리에 들어가있지않음)
	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
		System.out.println("--확인용-- SendMessage 진입");

		String mid = request.getParameter("mid");
		
		System.out.println("샌두메세지의 엠아이디 :"+mid);

		MessageDAO m = new MessageDAO();
		List<MessageVO> message = m.selectOneMessage(mid);
		
		
		System.out.println(message.size()+"여기는 메세지사이즈를 제는곳잆니다.");
		
		request.setAttribute("message", message);
		
		System.out.println(message.size()+"여기는 메세지사이즈를 제는곳잆니다2.");
		RequestDispatcher dispatcher = request.getRequestDispatcher("Boss/getMessage.jsp");
		dispatcher.forward(request, response);
		
		//완료되면 창이 꺼져야한다.
		
	}
}


