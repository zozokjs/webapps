package com.mf.action.manger;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mf.action.Action;


public class OpenMessage implements Action{
	//해당 판매자에게 쪽지를 보내는 액션
	//(아직 액션팩토리에 들어가있지않음)
	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
		System.out.println("--확인용-- OpenMessage 진입");
		
		String mid = request.getParameter("mid");
		request.setAttribute("mid", mid);
		
		RequestDispatcher dispatcher = request.getRequestDispatcher("Boss/sendMessage.jsp");
		dispatcher.forward(request, response);
		
		System.out.println("OpenMessage 다 읽음");
	}
}