package com.mf.action.manger;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mf.action.Action;
import com.mf.dao.MemberDAO;

public class ChangeOpnum implements Action{

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("--확인용-- ChangeOpnum 진입");
		
		String mid = request.getParameter("mid");
		request.setAttribute("mid", mid);
		
		RequestDispatcher dispatcher = request.getRequestDispatcher("Boss/ChangeOpnum.jsp");
		dispatcher.forward(request,response);	
		
		
		System.out.println("ChangeOpnum 다 읽음");
		
		
		
	}

}
