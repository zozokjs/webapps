package com.mf.action.manger;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mf.action.Action;
import com.mf.dao.MessageDAO;
import com.mf.dto.MessageVO;

public class getMessage2 implements Action {

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("--확인용-- SendMessage 진입");

		String mid = request.getParameter("mid");
		
		System.out.println("샌두메세지의 엠아이디 :"+mid);

		MessageDAO m = new MessageDAO();
		MessageVO message = m.selectOneMessage2(mid);
		
		
		System.out.println(message+"여기는 메세지사이즈를 제는곳잆니다.");
		
		request.setAttribute("message", message);
		
		
		RequestDispatcher dispatcher = request.getRequestDispatcher("Boss/getMessage2.jsp");
		dispatcher.forward(request, response);
	}
}
