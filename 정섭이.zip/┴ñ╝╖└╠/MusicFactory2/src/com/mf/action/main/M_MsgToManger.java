package com.mf.action.main;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mf.action.Action;
import com.mf.sms.SmsSend;

import sun.rmi.server.Dispatcher;

public class M_MsgToManger implements Action {

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String id = request.getParameter("id");
		String msg = request.getParameter("msg");

		int responseCode = SmsSend.sendSms(id, msg);

		if (responseCode == 1) {
			request.setAttribute("code", 1);
			RequestDispatcher dispatcher = request.getRequestDispatcher("Main/tempSms.jsp");
			dispatcher.forward(request, response);
		} else {
			RequestDispatcher dispatcher = request.getRequestDispatcher("Main/tempSms.jsp?code=2");
			dispatcher.forward(request, response);
		}

	}

}
