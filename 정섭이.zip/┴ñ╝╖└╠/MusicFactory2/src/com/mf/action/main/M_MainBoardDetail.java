package com.mf.action.main;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mf.action.Action;

public class M_MainBoardDetail implements Action
{

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String bnumber = request.getParameter("bnumber");
		int bnumber2 = Integer.parseInt(bnumber);
		
		
		
	}

}
