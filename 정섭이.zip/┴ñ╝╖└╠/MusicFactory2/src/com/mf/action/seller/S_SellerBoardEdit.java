package com.mf.action.seller;

import java.io.IOException;
import java.sql.Timestamp;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mf.action.Action;
import com.mf.dao.BoardDAO;
import com.mf.dto.BoardVO;

public class S_SellerBoardEdit implements Action {

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	System.out.println("--Ȯ�ο�-- ����� S_SellerBoardEdit ");
		
		String bnumber = request.getParameter("bnumber");
		int bnumber2 = Integer.parseInt(bnumber);
		
		BoardDAO bDao =BoardDAO.getInstance();
		BoardVO board  = bDao.selectOneBoard(bnumber2);
		
		String bauthor = board.getBauthor();
		String bcontent =board.getBcontent();
		Timestamp bdate=board.getBdate();
		String bjanre =board.getBjanre();
		int bnumber3 =board.getBnumber();
		String bpicture =board.getBpicture();
		int bprice = board.getBprice();
		int bscore = board.getBscore();
		String btitle =board.getBtitle();
		//String mid = board.getMid();
	
		request.setAttribute("bpicture",bpicture);			
		request.setAttribute("bnumber",bnumber3);		
		request.setAttribute("btitle",btitle);
		request.setAttribute("bprice",bprice);
		request.setAttribute("bauthor",bauthor);
		request.setAttribute("bjanre",bjanre);
		request.setAttribute("bcontent",bcontent);
		request.setAttribute("bdate",bdate);		
		request.setAttribute("bscore",bscore);
		
		
				
		RequestDispatcher dispatcher = request.getRequestDispatcher("Seller/S_SellerBoardEdit.jsp");
		dispatcher.forward(request, response);

		System.out.println("--Ȯ�ο�-- S_SellerBoardEdit �� ����");
		
	}

}
