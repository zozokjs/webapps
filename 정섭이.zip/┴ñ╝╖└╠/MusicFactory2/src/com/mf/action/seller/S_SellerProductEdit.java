package com.mf.action.seller;

import java.io.IOException;
import java.sql.Timestamp;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mf.action.Action;
import com.mf.dao.ProductDAO;
import com.mf.dto.ProductVO;

public class S_SellerProductEdit implements Action {

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	System.out.println("--확인용-- 여기는 S_SellerProductEdit ");
		
		String pnumber = request.getParameter("pnumber");
		int pnumber2 = Integer.parseInt(pnumber);
		
		ProductDAO pDao =ProductDAO.getInstance();
		ProductVO product  = pDao.selectOneProduct(pnumber2);
		
		String pauthor = product.getPauthor();
		Timestamp pdate=product.getPdate();
		String pjanre =product.getPjanre();
		int pnumber3 =product.getPnumber();
		String ppicture =product.getPpicture();
		int pprice = product.getPprice();
		int pscore = product.getPscore();
		String pname =product.getPname();
		//String mid = board.getMid();
	
		request.setAttribute("ppicture",ppicture);			
		request.setAttribute("pnumber",pnumber3);		
		request.setAttribute("pname",pname);
		request.setAttribute("pprice",pprice);
		request.setAttribute("pauthor",pauthor);
		request.setAttribute("pjanre",pjanre);
		request.setAttribute("pdate",pdate);		
		request.setAttribute("pscore",pscore);
		
		
				
		RequestDispatcher dispatcher = request.getRequestDispatcher("Seller/S_SellerProductEdit.jsp");
		dispatcher.forward(request, response);

		System.out.println("--확인용-- S_SellerProductEdit 다 읽음");
		
	}

}
