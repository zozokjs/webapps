package com.mf.action.buyer;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.mf.action.Action;
import com.mf.dao.OrderingDAO;
import com.mf.dao.ProductDAO;
import com.mf.dto.OrderingVO;
import com.mf.dto.PandOVO;
import com.mf.dto.ProductVO;

public class B_BuyerBasketView implements Action
{

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {		
		System.out.println("--확인용-- B_BuyerBasketView.java 진입");
		
		HttpSession session = request.getSession();
		String mid = (String) session.getAttribute("mid"); //구매자 아이디 / 받아오는거 확인

		System.out.println("mid>>>>>>>>>>>>> "+mid);
		
		OrderingDAO odao = OrderingDAO.getInstance();
		List<PandOVO> order = odao.selectAllByMidOrdering(mid);	
		
		String totalPrice = odao.sumTotalPrice(mid); //장바구니 총 가격. String 리턴됨
		System.out.println("총가격>> "+totalPrice);
		
		request.setAttribute("totalPrice", totalPrice);
		request.setAttribute("order", order);
		
		RequestDispatcher dis = request.getRequestDispatcher("Buyer/B_BuyerBasketView.jsp");
		dis.forward(request, response);
		
		
		System.out.println("B_BuyerOrder.java 통과");
	}

}
