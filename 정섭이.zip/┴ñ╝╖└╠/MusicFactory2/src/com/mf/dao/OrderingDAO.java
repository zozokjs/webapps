package com.mf.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.mf.DBManager.DBManager;
import com.mf.dto.OrderingVO;
import com.mf.dto.PandOVO;
import com.mf.dto.ProductVO;

//장바구니 목록을 위해 필요함

public class OrderingDAO 
{
	private OrderingDAO(){	}
	
	private static OrderingDAO instance = new OrderingDAO();
	
	public static OrderingDAO getInstance()
	{
		return instance;
	}

	public void insertOrdering(OrderingVO order) {
		String sql = "insert into ordering values(?,?,?,ordering_seq.nextval,?)";
		
		//String sql = "insert into ordering values('"+mid+"' ,"+pnumber+", "+ovolume+")";
		
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			conn = DBManager.getConnection();		
			pstmt = conn.prepareStatement(sql); 	
			pstmt.setString(1, order.getMid());	
			pstmt.setInt(2, order.getPnumber());
			pstmt.setInt(3, order.getOvolume());
			pstmt.setInt(4, order.getOtf());			
			rs = pstmt.executeQuery(); //sql 실행하여 얻은 결과를 rs에 저장한다. 
			System.out.println("--확인용-- insertOrdering 메소드 다 읽음");
		} 
		catch(Exception e)
		{
			System.out.println("insertOrdering 메소드에서 오류 발생");
			e.printStackTrace();
		}
		finally {
			try {conn.close();} 
			catch (SQLException e) 
			{
				System.out.println("insertOrdering 메소드에서 닫기 오류 발생");
				e.printStackTrace();
			}
		}
	}

	public List<PandOVO> selectAllByMidOrdering(String mid) {
		String sql = "select * from ordering o,product p where o.pnumber = p.pnumber order by onumber desc";		
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		List<PandOVO> arr = new ArrayList<PandOVO>();	
		try {			
			conn = DBManager.getConnection();
			pstmt = conn.prepareStatement(sql); 		
			rs = pstmt.executeQuery();		
			while(rs.next()) 	
			{
				PandOVO po= new PandOVO();	
				po.setMid(mid); //아이디
				po.setOnumber(rs.getInt("onumber")); //구매 혹은 장바구니 번호
				po.setOtf(rs.getInt("otf")); //구매 전후 파악 번호(0이면 구매 전. 1이면 구매 후(결제 후) )
				po.setOvolume(rs.getInt("ovolume")); //구매 수량
				po.setPamount(rs.getInt("pamount")); //제품 수량(재고)
				po.setPauthor(rs.getString("pauthor")); //제품 제작자
				po.setPdate(rs.getTimestamp("pdate")); //제품 게시 날짜
				po.setPjanre(rs.getString("pjanre")); //제품 장르
				po.setPname(rs.getString("pname")); //제품 이름
				po.setPnumber(rs.getInt("pnumber")); //제품 번호
				po.setPpicture(rs.getString("ppicture")); //제품 그림
				po.setPprice(rs.getInt("pprice")); //제품 가격
				po.setPscore(rs.getInt("pscore")); //제품 평점
				arr.add(po);
			}
		} 
		
		
		catch(Exception e)
		{
			System.out.println("selectAllByMidOrdering 메소드에서 오류 발생");
			e.printStackTrace();
		}
		
		finally {
			try {conn.close();} 
			catch (SQLException e) 
			{
				System.out.println("selectAllByMidOrdering 메소드에서 닫기 오류 발생");
				e.printStackTrace();
			}
		}
			
		return arr;	
	}

	public void DeleteOrdering(int onumber) {		
		String sql = "delete Ordering where onumber ="+onumber;
		Connection conn = null;
		PreparedStatement pstmt = null;
		{
			
			try {
				conn = DBManager.getConnection();
				pstmt = conn.prepareStatement(sql);
				pstmt.executeUpdate();
				System.out.println("DeleteOrdering 메소드 다 읽음");
				
				
			} catch (SQLException e) {
				System.out.println("DeleteOrdering 메소드에서 오류 발생");
				e.printStackTrace();
			} 
			finally {
				try {conn.close();} 
				catch (SQLException e) 
				{
					System.out.println("DeleteOrdering 메소드에서 닫기 오류 발생");
					e.printStackTrace();
				}
			}		
		}	
		
	}

	public String sumTotalPrice(String mid) 
	{
		String sql = "select sum(pprice*ovolume) from ordering o,product p where o.pnumber = p.pnumber order by onumber desc";		
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String totalPrice = "";
		try {			
			conn = DBManager.getConnection();
			pstmt = conn.prepareStatement(sql); 		
			rs = pstmt.executeQuery();		
			while(rs.next()) 	
			{
				totalPrice = rs.getString("sum(pprice*ovolume)");
			}
		} 				
		catch(Exception e)
		{
			System.out.println("sumTotalPrice 메소드에서 오류 발생");
			e.printStackTrace();
		}	
		finally {
			try {conn.close();} 
			catch (SQLException e) 
			{
				System.out.println("sumTotalPrice 메소드에서 닫기 오류 발생");
				e.printStackTrace();
			}
		}	
		return totalPrice;
	}

	public void EditOrdering(int onumber2, int ovolume2) {
		String sql = "update ordering set ovolume = "+ovolume2+" where onumber ="+onumber2;
		Connection conn = null;
		PreparedStatement pstmt = null;
		{		
			try {
				conn = DBManager.getConnection();
				pstmt = conn.prepareStatement(sql);
				pstmt.executeUpdate();
				System.out.println("EditOrdering 메소드 다 읽음");				
			} catch (SQLException e) {
				System.out.println("EditOrdering 메소드에서 오류 발생");
				e.printStackTrace();
			} 
			finally {
				try {conn.close();} 
				catch (SQLException e) 
				{
					System.out.println("EditOrdering 메소드에서 닫기 오류 발생");
					e.printStackTrace();
				}
			}		
		}	
		
	}
	
	
	
	
}
