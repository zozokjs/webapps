package com.mf.controller;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mf.action.Action;
import com.mf.dao.MemberDAO;
import com.mf.dto.UserVo;


/**
 * Servlet implementation class UserSearchServlet
 */
@WebServlet("/KaKaoServlet")
public class KaKaoServlet extends HttpServlet implements Action{
   private static final long serialVersionUID = 1L;

   StringBuffer res;
   
   protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
      System.out.println("--확인용-- 여기는 KaKaoServlet의 doPost");
      request.setCharacterEncoding("UTF-8");
      response.setContentType("text/html;charset=UTF-8");
      //String res = request.getParameter("res");
      response.getWriter().write(getContent());
      System.out.println("깨깨오톡 :"+res);
   }
   
   public String getContent() throws IOException {
      
      BufferedReader in;
      System.out.println("ajax/getContent");
      
      URL url = new URL("http://211.249.61.120:8000/MFServer/getContent");
      HttpURLConnection con = (HttpURLConnection) url.openConnection();

      con.setRequestProperty("Content-Type", "text/plain; charset=utf-8");
      con.setRequestMethod("GET");
      con.setConnectTimeout(5000);
      con.connect();            
      
      int responseCode = con.getResponseCode();
      if(responseCode == 200){
         in = new BufferedReader(new InputStreamReader(con.getInputStream()));
      }else{ 
         in = new BufferedReader(new InputStreamReader(con.getErrorStream()));
      }
      
      String inputData;
      res = new StringBuffer();
      
      while((inputData = in.readLine()) != null){
         res.append(inputData);
      }
      
      in.close();

      return res.toString();      
   }

   @Override
   public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
      doPost(request, response);
      
   }

}