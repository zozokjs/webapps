package com.mf.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mf.action.Action;
import com.mf.dao.MemberDAO;
import com.mf.dto.UserVo;


/**
 * Servlet implementation class UserSearchServlet
 */
@WebServlet("/UserSearchServlet")
public class UserSearchServlet extends HttpServlet implements Action{
	private static final long serialVersionUID = 1L;

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("--확인용-- 여기는 UserSearchServlet의 doPost");
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html;charset=UTF-8");
		String userName = request.getParameter("userName");
		response.getWriter().write(getJSON(userName));
		System.out.println("안녕");
	}
	
	public String getJSON(String userName) {
		
		System.out.println("--확인용-- 여기는  UserSearchServlet의 getJSON");
		String a = "<a href='MFServlet?command=S_SellerProductDetail'>상세보기</a>";

		if(userName == null) userName = "";
		StringBuffer result = new StringBuffer("");
		result.append("{\"result\":[");
		MemberDAO userDAO = MemberDAO.getInstance() ;
		ArrayList<UserVo> userList = userDAO.search(userName);
		for(int i=0; i<userList.size(); i++) {
			result.append("[{\"value\": \""+ userList.get(i).getPname()+"\"}],");
			/*result.append("{\"value\": \""+ userList.get(i).getPauthor()+"\"},");
			result.append("{\"value\": \""+ userList.get(i).getPjanre()+"\"},"); 
			result.append("{\"value\": \""+ userList.get(i).getPprice()+
			"\"},");
			result.append("{\"value\": \""+"<a href='MFServlet?command=S_SellerProductDetail&pnumber="+userList.get(i).getPnumber()+"'>상세보기</a>"+"\"}],");*/
		}
		result.append("]}");
		System.out.println(result.toString()+"");
		return result.toString();
	}

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
		
	}

}
