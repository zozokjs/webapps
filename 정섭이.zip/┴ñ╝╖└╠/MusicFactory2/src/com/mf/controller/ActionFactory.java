package com.mf.controller;

import com.mf.action.Action;
import com.mf.action.buyer.B_BuyerDetail;
import com.mf.action.buyer.B_BuyerOrderDelete;
import com.mf.action.buyer.B_BuyerOrderEdit;
import com.mf.action.buyer.B_BuyerBacketInsert;
import com.mf.action.buyer.B_BuyerBasketView;
import com.mf.action.buyer.B_BuyerDeliveryList;
import com.mf.action.buyer.B_BuyerOrderWrite;
import com.mf.action.buyer.B_BuyerPurchaseInsert;
import com.mf.action.main.M_MainCategorySelect;
import com.mf.action.main.M_MainCategorySelect2;
import com.mf.action.main.M_MainProductDetail;
import com.mf.action.main.M_MainProductDetail2;
import com.mf.action.main.M_SearchSys;
import com.mf.action.main.M_SearchSys2;
import com.mf.action.main.M_MsgToManger;
import com.mf.action.main.MainPage;
import com.mf.action.main.MainPage2;
import com.mf.action.manger.ChangeOpnum;
import com.mf.action.manger.ChangeOpnum2;
import com.mf.action.manger.ChangeOpnumZero;
import com.mf.action.manger.ManageSeller;
import com.mf.action.manger.OpenMessage;
import com.mf.action.manger.SendMessage;
import com.mf.action.manger.getMessage;
import com.mf.action.manger.getMessage2;
import com.mf.action.manger.goManaging;
import com.mf.action.member.M_AlertPage;
import com.mf.action.member.M_InsertMember;
import com.mf.action.member.M_LoginMember;
import com.mf.action.member.M_LoginNaverMember;
import com.mf.action.member.M_LoginNaverMemberToMainP;
import com.mf.action.seller.S_SellerProductDelete;
import com.mf.action.seller.S_SellerProductDetail;
import com.mf.action.seller.S_SellerProductEdit;
import com.mf.action.seller.S_SellerProductInsert;
import com.mf.action.seller.S_SellerProductUpdate;
import com.mf.action.seller.S_SellerMain;

public class ActionFactory 
{
	private ActionFactory()
	{
		
	}
	
	private static ActionFactory instance = new ActionFactory();
	public static ActionFactory getInstance()
	{
		return instance;
	}
	
	public Action getAction(String command)
	{
		Action action = null;
		if(command.equals("MainPage"))
		{
			//최초 메인 페이지(로그인 안 된) 접근시
			action = new MainPage();
			System.out.println("--확인용-- 여기는 A.F.의 MainPage 분기문 통과--");
		}
		else if(command.equals("M_LoginMember"))
		{
			
			//로그인시 접근
			action = new M_LoginMember();	
			System.out.println("--확인용-- 여기는 A.F.의 M_LoginMember 분기문 통과");
			
		}
		else if(command.equals("M_InsertMember")) //회원가입 
		{
			
			//회원가입시 접근		
			action  = new M_InsertMember();
			System.out.println("--확인용-- 여기는 A.F.의 M_InsertMember 분기문 통과");
		}
		else if(command.equals("S_SellerMain"))
		{ 
			//판매자 로그인 후, 판매자 메인 페이지 버튼 클릭시 접근
			action = new S_SellerMain();			
			System.out.println("--확인용-- 여기는 A.F.의 S_SellerMain 분기문 통과");
			
		}
		else if(command.equals("S_SellerProductInsert"))
		{
			//판매자가 상품 올리면 여기로 옴
			action = new S_SellerProductInsert();
			System.out.println("--확인용-- 여기는 A.F.의 S_SellerProductInsert 분기문 통과");
			
		}
		else if(command.equals("S_SellerProductDetail"))
		{
			//판매자 로그인 상태에서 판매자 메인 -> 상세 보기 선택시 여기로 옴
			action = new S_SellerProductDetail();
			
			System.out.println("--확인용-- 여기는 A.F.의 S_SellerProductDetail 분기문 통과 ");
			
		}
		else if(command.equals("S_SellerProductEdit"))
		{
			action = new S_SellerProductEdit();
			System.out.println("--확인용-- 여기는 A.F.의 S_SellerProductEdit 분기문 통과");
			
			
		}	
		else if(command.equals("S_SellerProductUpdate"))
		{
			action = new S_SellerProductUpdate();
			System.out.println("--확인용-- 여기는 A.F.의 S_SellerProductUpdate 분기문 통과");
			
		}
		else if(command.equals("S_SellerProductDelete"))
		{
			action = new S_SellerProductDelete();
			System.out.println("--확인용-- 여기는 A.F.의 S_SellerProductDelete 분기문 통과");			
			
		}
		else if(command.equals("MainPage2"))
		{
			//메인 페이지2(로그인 된) 접근시
			action = new MainPage2();
			System.out.println("--확인용-- 여기는 A.F.의 MainPage2 분기문 통과");	
			
			
		}else if(command.equals("M_MainProductDetail"))
		{
			//메인 페이지2(로그인 된) 접근시
			action = new M_MainProductDetail();
			System.out.println("--확인용-- 여기는 A.F.의 M_MainProductDetail 분기문 통과");	
			
			
		}
		else if(command.equals("goManaging"))
		{
			action = new goManaging();
			
			System.out.println("--확인용-- 여기는 A.F.의 goManaging 분기문 통과");	
			
			
		
		}
		else if(command.equals("ManageSeller"))
		{
			
			action = new ManageSeller();			 
			System.out.println("--확인용-- 여기는 A.F.의 ManageSeller 분기문 통과");	
			
			
		
		}
		else if(command.equals("M_MainProductDetail2"))
		{
			
			//로그인 된 메인페이지에서 상품 클릭 했을 때 
			
			action = new M_MainProductDetail2();	
			System.out.println("--확인용-- 여기는 A.F.의  M_MainProductDetail2분기문 통과");	
			
			
		
		}
		else if(command.equals("B_BuyerDetail"))
		{
			action = new B_BuyerDetail();
			 
			System.out.println("--확인용-- 여기는 A.F.의 B_BuyerOrderReceipt 분기문 통과");	
			
			
		
		}
		else if(command.equals("B_BuyerOrderWrite"))
		{
			action = new B_BuyerOrderWrite();
			 
			System.out.println("--확인용-- 여기는 A.F.의 B_BuyerOrderWrite 분기문 통과");	
			
			
		
		}
		else if(command.equals("M_MainCategorySelect"))
		{
			
			action = new M_MainCategorySelect();
			System.out.println("--확인용-- 여기는 A.F.의 M_MainCategorySelect 분기문 통과");	
			
			
		}
		else if(command.equals("M_MainCategorySelect2"))
		{
			
			action = new M_MainCategorySelect2();
			System.out.println("--확인용-- 여기는 A.F.의 M_MainCategorySelect2 분기문 통과");	
			
			
		}else if(command.equals("M_SearchSys"))
		{
			
			action = new M_SearchSys();
			System.out.println("--확인용-- 여기는 A.F.의 M_SearchSys 분기문 통과");	
			
			
		}else if(command.equals("M_SearchSys2"))
		{
			
			action = new M_SearchSys2();
			System.out.println("--확인용-- 여기는 A.F.의 M_SearchSys2 분기문 통과");	
			
			
		}else if(command.equals("ChangeOpnum"))
		{
			
			action = new ChangeOpnum();
			System.out.println("--확인용-- 여기는 A.F.의 ChangeOpnum 분기문 통과");					
		}
		else if(command.equals("ChangeOpnum2"))
		{
			
			action = new ChangeOpnum2();
			System.out.println("--확인용-- 여기는 A.F.의 ChangeOpnum2 분기문 통과");							
		}
		else if(command.equals("ChangeOpnumZero"))
		{
			
			action = new ChangeOpnumZero();
			System.out.println("--확인용-- 여기는 A.F.의 ChangeOpnumZero 분기문 통과");				
		}
		else if(command.equals("B_BuyerBacketInsert"))
		{
			
			action = new B_BuyerBacketInsert();
			System.out.println("--확인용-- 여기는 A.F.의 B_BuyerBacketInsert 분기문 통과");				
		}
		else if(command.equals("B_BuyerBasketView"))
		{
			
			action = new B_BuyerBasketView();
			System.out.println("--확인용-- 여기는 A.F.의 B_BuyerBasketView 분기문 통과");				
		}
		else if(command.equals("B_BuyerOrderDelete"))
		{
			
			action = new B_BuyerOrderDelete();
			System.out.println("--확인용-- 여기는 A.F.의 B_BuyerOrderDelete 분기문 통과");				
		}else if(command.equals("M_LoginNaverMember"))
		{
			
			action = new M_LoginNaverMember();
			System.out.println("--확인용-- 여기는 A.F.의 M_LoginNaverMember 분기문 통과");				
		}else if(command.equals("OpenMessage"))
		{
			
			action = new OpenMessage();
			System.out.println("--확인용-- 여기는 A.F.의 OpenMessage 분기문 통과");				
		}else if(command.equals("SendMessage"))
		{
			
			action = new SendMessage();
			System.out.println("--확인용-- 여기는 A.F.의 SendMessage 분기문 통과");
			
		}else if(command.equals("M_LoginNaverMemberToMainP"))
		{
			
			action = new M_LoginNaverMemberToMainP();
			System.out.println("--확인용-- 여기는 A.F.의 M_LoginNaverMemberToMainP 분기문 통과");				
		}else if(command.equals("M_AlertPage"))
		{
			
			action = new M_AlertPage();
			System.out.println("--확인용-- 여기는 A.F.의 M_AlertPage 분기문 통과");				
		}else if(command.equals("UserSearchServlet"))
		{
			
			action = new UserSearchServlet();
			System.out.println("--확인용-- 여기는 A.F.의 UserSearchServlet 분기문 통과");				
		}else if(command.equals("B_BuyerPurchaseInsert"))
		{
			
			action = new B_BuyerPurchaseInsert();
			System.out.println("--확인용-- 여기는 A.F.의 B_BuyerPurchaseInsert 분기문 통과");				
		}else if(command.equals("B_BuyerDeliveryList"))
		{
			
			action = new B_BuyerDeliveryList();
			System.out.println("--확인용-- 여기는 A.F.의 B_BuyerDeliveryList 분기문 통과");				
		}else if(command.equals("B_BuyerOrderEdit"))
		{
			
			action = new B_BuyerOrderEdit();
			System.out.println("--확인용-- 여기는 A.F.의 B_BuyerOrderEdit 분기문 통과");				
		}else if(command.equals("GetMessage"))
		{
			
			action = new getMessage();
			System.out.println("--확인용-- 여기는 A.F.의 getMessage 분기문 통과");				
		}else if(command.equals("GetMessage2"))
		{
			
			action = new getMessage2();
			System.out.println("--확인용-- 여기는 A.F.의 getMessage2 분기문 통과");				
		}else if(command.equals("M_MsgToManger"))
		{
			
			action = new M_MsgToManger();
			System.out.println("--확인용-- 여기는 A.F.의 M_MsgToManger 분기문 통과");				
		}else if(command.equals("KaKaoServlet"))
		{
			
			action = new KaKaoServlet();
			System.out.println("--확인용-- 여기는 A.F.의 KaKaoServlet 분기문 통과");				
		}
		
		
		
		
		
		
	
		
		
		return action;
				
		
	}
	
}
