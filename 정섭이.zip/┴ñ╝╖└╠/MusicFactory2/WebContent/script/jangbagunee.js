/**
 * 
 */

function jangbagunee()
{	
	alert("오정섭입니다.");
	if(document.jangT.jang7.value.length == 0)
	{
		alert("0이상이나 숫자를 입력해주세요");
		jangT.jang7.focus();
		return false;
	}
	return true;
}