/**
 * 
 */

function insertMember()
{	
	if(document.frm3.mid.value.length == 0)
	{
		alert("아이디를 입력해야 합니다");
		frm3.mid.focus();
		return false;
	}
	if(document.frm3.mpwd.value.length == "")
	{
		alert("비밀번호를 입력해야 합니다");
		frm3.mpwd.focus();
		return false;
	}
	if(document.frm3.mname.value.length == 0)
	{
		alert("아이디를 입력해야 합니다");
		frm3.mid.focus();
		return false;
	}
	if(document.frm3.mbirth.value.length == "")
	{
		alert("비밀번호를 입력해야 합니다");
		frm3.mpwd.focus();
		return false;
	}
	if(document.frm3.memail.value.length == 0)
	{
		alert("아이디를 입력해야 합니다");
		frm3.mid.focus();
		return false;
	}
	if(document.frm3.maddr.value.length == "")
	{
		alert("비밀번호를 입력해야 합니다");
		frm3.mpwd.focus();
		return false;
	}
	return true;
}