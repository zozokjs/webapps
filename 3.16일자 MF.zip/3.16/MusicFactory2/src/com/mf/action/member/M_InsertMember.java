package com.mf.action.member;

import java.io.IOException;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mf.action.Action;
import com.mf.dao.MemberDAO;
import com.mf.dto.MemberVO;

public class M_InsertMember implements Action
{
	//여기서는 페이지 이동이 이뤄져야 한다.
	
	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		//request에는 사용자가 입력한 정보가 담겨 있다.
		String mid = request.getParameter("mid");
		String mpwd = request.getParameter("mpwd");
		String mname = request.getParameter("mname");
		String mbirth = request.getParameter("mbirth"); 	
		
		//String으로 넘어온 값을 TimeStamp형으로 형변환하는 과정
		//사용자가 입력한 값은 2018-02-02 형식으로 넘어옴
			SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
			Date date = null;
			Timestamp ts = null;
			try 
			{
				date = formatter.parse(mbirth);
				ts = new Timestamp(date.getTime());
			} 
			catch (ParseException e) 
			{		
				System.out.println("확인용 // 여기는 M_InsertMember 클래스");
				System.out.println("사용자가 입력한 date 형변환 과정 중 오류 발생");
				e.printStackTrace();
			}
		
		String memail = request.getParameter("memail");
		String mphone = request.getParameter("mphone");
		String maddr = request.getParameter("maddr");
		String mjanre = request.getParameter("mjanre");
		int mgrade = Integer.parseInt(request.getParameter("mgrade"));
		int mopnum= Integer.parseInt(request.getParameter("mopnum"));
		int mwarning = Integer.parseInt(request.getParameter("mwarning"));
			
		MemberVO vo = new MemberVO();
		vo.setMid(mid);
		vo.setMpwd(mpwd);
		vo.setMname(mname);
		vo.setMbirth(ts);
		vo.setMemail(memail);
		vo.setMphone(mphone);
		vo.setMaddr(maddr);
		vo.setMjanre(mjanre);
		vo.setMgrade(mgrade);
		vo.setMopnum(mopnum);
		vo.setMwarning(mwarning);

		MemberDAO mdao =  MemberDAO.getInstance();
		mdao.insertMember(vo);
		response.sendRedirect("Member/M_LoginMember.jsp");
		
		
	}

}
