/*package com.mf.action.member;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.mf.action.Action;
import com.mf.dao.MemberDAO;
import com.mf.dto.ProductVO;
import com.mf.dto.MemberVO;

public class M_LoginSuccess implements Action
{

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//로그인 성공하면 여기로 이동됨... 메인 페이지로 이동시키기
		
		String mid = request.getParameter("mid");
		System.out.println("여기는 M_LoginSuccess>>> mid는?>>>>>>>>>>> "+mid);
		
		MemberDAO mDao = null; 
		mDao = mDao.getInstance();
		
		MemberVO m = mDao.selectOneMember(mid);
		
		//아이디 비번 주소.......
		String id = m.getMid();
		String name = m.getMname();
	
		request.setAttribute("id", id);
		request.setAttribute("name", name);
	
		BoardDAO bDao = null;
		bDao = bDao.getInstance();
		
		List<ProductVO> board = bDao.selectAllByDate();
		request.setAttribute("board", board);		
		
		
		//***********************************************************
		//grade 가 1 이면 관리자 -> 관리자 메인 페이지
		//2면 판매자 메인 페이지
		//3이면 구매자(일반회원) 메인 페이지.
	
		int g = m.getMgrade();		
		if(g==1) {
			//관리자 메인 페이지 없음(임시)
			RequestDispatcher dispatcher = request.getRequestDispatcher("/Boss/manageMain.jsp");
			dispatcher.forward(request, response);
			
		}else if(g==2) {
			//판매자 메인 페이지			
			RequestDispatcher dispatcher = request.getRequestDispatcher("MFServlet.do?command=S_SellerMain");
			dispatcher.forward(request, response);
			
		}else if(g==3) {

			//여기서는 MainPage2에 bpicture 값을 던져야 한다. 
			//메인
			RequestDispatcher dispatcher = request.getRequestDispatcher("MFServlet.do?command=goMain2");
			dispatcher.forward(request, response);
		}
	


		
	
		
		
	}

}
*/