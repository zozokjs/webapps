package com.mf.action.main;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mf.action.Action;
import com.mf.dao.ProductDAO;
import com.mf.dto.ProductVO;

public class M_MainCategorySelect implements Action
{

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("--확인용-- M_MainCategorySelect.java 진입");
		
		String pjanre = request.getParameter("pjanre");
		
		//선택한 장르에 대한 모든 제품을 가져 올 수 있어야 함
		
		ProductDAO pdao = ProductDAO.getInstance();
		List<ProductVO> product = pdao.selectCategory(pjanre);
		
		
		request.setAttribute("product", product);
		RequestDispatcher dispatcher = request.getRequestDispatcher("Main/M_MainCategorySelect.jsp");
		dispatcher.forward(request, response);
		
		
		System.out.println("M_MainCategorySelect.java 통과");
	}

}
