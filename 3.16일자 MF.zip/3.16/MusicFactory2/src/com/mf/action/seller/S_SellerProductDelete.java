package com.mf.action.seller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.mf.action.Action;
import com.mf.dao.ProductDAO;
import com.mf.dto.ProductVO;

public class S_SellerProductDelete implements Action
{

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("--확인용-- 여기는 S_SellerProductDelete ");
		String pnum = request.getParameter("pnumber");
		int pnumber = Integer.parseInt(pnum);
		
		HttpSession session = request.getSession();
		String mid = (String)session.getAttribute("mid");
		
		ProductDAO pdao = ProductDAO.getInstance();
		pdao.DeleteProduct(pnumber); //삭제를 위해 사용하는 메소드
				
		request.setAttribute("mid", mid); //세션에서 mid만 가져 와서 S_SellerMain.java로 던짐 
				
		RequestDispatcher dispatcher = request.getRequestDispatcher("MFServlet?command=S_SellerMain");
		dispatcher.forward(request, response);
		System.out.println("S_SellerProductDelete 다 읽음");
		
	}

}
