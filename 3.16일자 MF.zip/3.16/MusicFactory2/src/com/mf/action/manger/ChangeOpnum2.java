package com.mf.action.manger;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mf.action.Action;
import com.mf.dao.MemberDAO;
import com.mf.dto.MemberVO;

public class ChangeOpnum2 implements Action
{

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("--확인용-- ChangeOpnum2 진입");
		
		String mid = (String) request.getParameter("mid");
		String mopnum = (String) request.getParameter("mopnum");	
		int mopnum2 = Integer.parseInt(mopnum);
		System.out.println("sds>>>>>>>>>>>>>>>  "+mopnum);		
		
		MemberDAO mdao = MemberDAO.getInstance();
		mdao.changeOpnum(mid,mopnum2);	
		List<MemberVO> member = mdao.selectByGradeMember(2); //판매자 등급이 2임;
	
		request.setAttribute("member", member);
		
		RequestDispatcher dispatcher = request.getRequestDispatcher("Boss/manageMain.jsp");
		dispatcher.forward(request, response);
		
		
		System.out.println("ChangeOpnum2 다 읽음");
	}

}
