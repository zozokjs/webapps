package com.mf.DBManager;
//Music Factory의 DBManager 
import java.sql.Connection;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

public class DBManager 
{
	public static Connection getConnection()
	{
		Connection conn = null;
		
		try 
		{			
			Context initContext = new InitialContext();
			Context envContext  = (Context)initContext.lookup("java:/comp/env");
			DataSource ds = (DataSource)envContext.lookup("jdbc/myoracle");
			conn = ds.getConnection();
			System.out.println("디비 연결 성공");
		} catch (Exception e) {
			System.out.println("디비 연결 실패"+e);
			e.printStackTrace();
		}
		
		return conn;
		
	}
	
}
	
