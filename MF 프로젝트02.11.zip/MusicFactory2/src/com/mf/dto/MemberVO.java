package com.mf.dto;
//Music Factory의 MusicVO
import java.sql.Timestamp;

public class MemberVO 
{
	private String mid; //아이디
	private String mpwd; //비번
	private String mname; //이름
	private Timestamp mbirth; //생년월일
	private String memail; //이메일
	private String mphone; //폰번호
	private String maddr; //주소
	private String mjanre; //장르
	private int mgrade; //회원등급(사용자, 판매자, 최고 관리자 구분)
	///////////////////////////////////////////////////////
	private int mopnum; //사업자 번호
	private int mwarning ;
	
	
	public String getMid() {
		return mid;
	}
	public void setMid(String mid) {
		this.mid = mid;
	}
	public String getMpwd() {
		return mpwd;
	}
	public void setMpwd(String mpwd) {
		this.mpwd = mpwd;
	}
	public String getMname() {
		return mname;
	}
	public void setMname(String mname) {
		this.mname = mname;
	}
	public Timestamp getMbirth() {
		return mbirth;
	}
	public void setMbirth(Timestamp mbirth) {
		this.mbirth = mbirth;
	}
	public String getMemail() {
		return memail;
	}
	public void setMemail(String memail) {
		this.memail = memail;
	}
	public String getMphone() {
		return mphone;
	}
	public void setMphone(String mphone) {
		this.mphone = mphone;
	}
	public String getMaddr() {
		return maddr;
	}
	public void setMaddr(String maddr) {
		this.maddr = maddr;
	}
	public String getMjanre() {
		return mjanre;
	}
	public void setMjanre(String mjanre) {
		this.mjanre = mjanre;
	}
	public int getMgrade() {
		return mgrade;
	}
	public void setMgrade(int mgrade) {
		this.mgrade = mgrade;
	}
	public int getMopnum() {
		return mopnum;
	}
	public void setMopnum(int mopnum) {
		this.mopnum = mopnum;
	}
	public int getMwarning () {
		return mwarning ;
	}
	public void setMwarning (int mwarning ) {
		this.mwarning  = mwarning ;
	}
	
	
	
	
	
	
	
}
