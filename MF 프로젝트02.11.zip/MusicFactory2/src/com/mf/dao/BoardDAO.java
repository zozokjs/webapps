package com.mf.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.mf.DBManager.DBManager;
import com.mf.dto.BoardVO;
import com.mf.dto.MemberVO;

public class BoardDAO 
{
	
	private BoardDAO() {}
	
	private static BoardDAO instance = new BoardDAO();
	
	public static BoardDAO getInstance()
	{
		return instance;
	}
	
	public void insertBoard(BoardVO vo) //회원가입 jsp페이지에서 하여튼 뭔가 회원가입정보를 통째로 받아옴
	{
		
		//bnumber, btitle, bcontent, bdate, bpicture, bscore, bprice, bjanre, bauthor, bdate, mid
		String sql 
		= "insert into board(bnumber, btitle, bcontent, bdate, bpicture, bscore, bprice, bjanre, bauthor, mid) "
				+ "values (board_seq.nextval,?,?,?,?,?,?,?,?,?)";
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			conn = DBManager.getConnection();
			pstmt = conn.prepareStatement(sql); 
			pstmt.setString(1, vo.getBtitle());
			pstmt.setString(2, vo.getBcontent());
			pstmt.setTimestamp(3, vo.getBdate());
			pstmt.setString(4, vo.getBpicture());
			pstmt.setInt(5, vo.getBscore());
			pstmt.setInt(6, vo.getBprice());
			pstmt.setString(7, vo.getBjanre());
			pstmt.setString(8, vo.getBauthor());
			pstmt.setString(9, vo.getMid());
							
			rs = pstmt.executeQuery(); //sql 실행하여 얻은 결과를 rs에 저장한다. 
			System.out.println("확인용// insertBoard 메소드 다 읽음");
		} 
		catch(Exception e)
		{
			System.out.println("insertBoard 메소드에서 오류 발생");
			e.printStackTrace();
		}
		finally {
			try {conn.close();} 
			catch (SQLException e) 
			{
				System.out.println("insertBoard 메소드에서 닫기 오류 발생");
				e.printStackTrace();
			}
		}
		
		
	}
	
	
	public List<BoardVO> selectAllBySeller(String mid){
		String sql = "select * from board where mid = "+ mid;			
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		List<BoardVO> arr = new ArrayList<BoardVO>();		
		
		try {			
			//연결을 얻어온다.
			conn = DBManager.getConnection();
			pstmt = conn.prepareStatement(sql); 
			//pstmt.setString(1, mid);
			rs = pstmt.executeQuery(); //sql 실행하여 얻은 결과를 rs에 저장한다. 
			
			while(rs.next()) 
			{
				BoardVO b = new BoardVO();		
				b.setBnumber(rs.getInt("bnumber"));
				b.setBtitle(rs.getString("btitle"));	
				b.setBcontent(rs.getString("bcontent"));
				b.setBpicture(rs.getString("bpicture"));
				b.setMid(rs.getString("mid"));
				b.setBscore(rs.getInt("bscore"));
				b.setBprice(rs.getInt("bprice"));
				b.setBjanre(rs.getString("bjanre"));
				b.setBauthor(rs.getString("bauthor"));
				arr.add(b);
			}
		} 
		
			
		catch(Exception e)
		{
			System.out.println("selectAllBySeller 메소드에서 오류 발생");
			e.printStackTrace();
		}
		
		finally {
			try {conn.close();} 
			catch (SQLException e) 
			{
				System.out.println("selectAllBySeller 메소드에서 닫기 오류 발생");
				e.printStackTrace();
			}
		}
			
		return arr;	
		
	}
	
	
	public List<BoardVO> selectAllByDate(){
		String sql = "select * from board order by bdate desc";	
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		List<BoardVO> arr = new ArrayList<BoardVO>();		
		
		try {			
			//연결을 얻어온다.
			conn = DBManager.getConnection();
			pstmt = conn.prepareStatement(sql); 
			//pstmt.setString(1, mid);
			rs = pstmt.executeQuery(); //sql 실행하여 얻은 결과를 rs에 저장한다. 
			
			while(rs.next()) 
			{
				BoardVO b = new BoardVO();	
				b.setBnumber(rs.getInt("bnumber"));
				b.setBtitle(rs.getString("btitle"));	
				b.setBcontent(rs.getString("bcontent"));
				b.setBpicture(rs.getString("bpicture"));
				b.setMid(rs.getString("mid"));
				b.setBscore(rs.getInt("bscore"));
				b.setBprice(rs.getInt("bprice"));
				b.setBjanre(rs.getString("bjanre"));
				b.setBauthor(rs.getString("bauthor"));
				arr.add(b);
			}
		} 
		
			
		catch(Exception e)
		{
			System.out.println("selectAllBySeller 메소드에서 오류 발생");
			e.printStackTrace();
		}
		
		finally {
			try {conn.close();} 
			catch (SQLException e) 
			{
				System.out.println("selectAllBySeller 메소드에서 닫기 오류 발생");
				e.printStackTrace();
			}
		}
			
		return arr;	
		
	}
	
	public BoardVO selectOneBoard(int bnumber){
		String sql = "select * from board where bnumber = ?";	
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		BoardVO b = new BoardVO();		
		try {			
			
			conn = DBManager.getConnection();
			pstmt = conn.prepareStatement(sql); 
			pstmt.setInt(1, bnumber);
			rs = pstmt.executeQuery(); 
			
			if(rs.next()) 
			{
				b.setBnumber(rs.getInt("bnumber"));		
				b.setBtitle(rs.getString("btitle"));	
				b.setBcontent(rs.getString("bcontent"));
				b.setBpicture(rs.getString("bpicture"));
				b.setMid(rs.getString("mid"));
				b.setBscore(rs.getInt("bscore"));
				b.setBprice(rs.getInt("bprice"));
				b.setBjanre(rs.getString("bjanre"));
				b.setBauthor(rs.getString("bauthor"));
				b.setBdate(rs.getTimestamp("bdate"));
				
			}
		} 
					
		catch(Exception e)
		{
			System.out.println("selectOneBoard 메소드에서 오류 발생");
			e.printStackTrace();
		}
		
		finally {
			try {conn.close();} 
			catch (SQLException e) 
			{
				System.out.println("selectOneBoard 메소드에서 닫기 오류 발생");
				e.printStackTrace();
			}
		}
			
		return b;
		
	}//셀렉트1 끝

	public void updateBoard(BoardVO vo) 
	{					
		int bnumber = vo.getBnumber();
		String sql = "update board set btitle = ?, bcontent =?, bdate =?, bpicture =?, "
						+ "bscore =?, bprice=?, bjanre=?, bauthor=? where bnumber = "+bnumber;
		Connection conn = null;
		PreparedStatement pstmt = null;
				
		try {
			conn = DBManager.getConnection();
			pstmt = conn.prepareStatement(sql); 
			pstmt.setString(1, vo.getBtitle());
			pstmt.setString(2, vo.getBcontent());
			pstmt.setTimestamp(3, vo.getBdate());
			pstmt.setString(4, vo.getBpicture());
			pstmt.setInt(5, vo.getBscore());
			pstmt.setInt(6, vo.getBprice());
			pstmt.setString(7, vo.getBjanre());
			pstmt.setString(8, vo.getBauthor());									
			pstmt.executeUpdate();
			System.out.println("updateBoard 메소드 다 읽음");
		} 
		catch(Exception e)
		{
			System.out.println("updateBoard 메소드에서 오류 발생");
			e.printStackTrace();
		}
		finally {
			try {conn.close();} 
			catch (SQLException e) 
			{
				System.out.println("updateBoard 메소드에서 닫기 오류 발생");
				e.printStackTrace();
			}
		}
	}
	
	public void DeleteBoard(int bnumber) 
	{
		String sql = "delete board where bnumber ="+bnumber;
		Connection conn = null;
		PreparedStatement pstmt = null;
		{
			
			try {
				conn = DBManager.getConnection();
				pstmt = conn.prepareStatement(sql);
				pstmt.executeUpdate();
				System.out.println("DeleteBoard 메소드 다 읽음");
				
				
			} catch (SQLException e) {
				System.out.println("DeleteBoard 메소드에서 오류 발생");
				e.printStackTrace();
			} 
			finally {
				try {conn.close();} 
				catch (SQLException e) 
				{
					System.out.println("DeleteBoard 메소드에서 닫기 오류 발생");
					e.printStackTrace();
				}
			}		
		}	
	}
	
		
		
		
	
	
	
	
	
	
	
	
	
	
}
