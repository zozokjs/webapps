package com.mf.controller;

import com.mf.action.Action;
import com.mf.action.goMain;
import com.mf.action.goMain2;
import com.mf.action.main.MainPage;
import com.mf.action.main.MainPage2;
import com.mf.action.member.M_InsertMember;
import com.mf.action.member.M_LoginMember;
import com.mf.action.member.M_LoginSuccess;
import com.mf.action.seller.S_SellerBoardDelete;
import com.mf.action.seller.S_SellerBoardDetail;
import com.mf.action.seller.S_SellerBoardEdit;
import com.mf.action.seller.S_SellerBoardInsert;
import com.mf.action.seller.S_SellerBoardUpdate;
import com.mf.action.seller.S_SellerMain;

public class ActionFactory 
{
	private ActionFactory()
	{
		
	}
	
	private static ActionFactory instance = new ActionFactory();
	public static ActionFactory getInstance()
	{
		return instance;
	}
	
	public Action getAction(String command)
	{
		Action action = null;
		if(command.equals("MainPage"))
		{
			//최초 메인 페이지(로그인 안 된) 접근시
			action = new MainPage();
			System.out.println("--확인용-- MainPage 분기문 통과--");
		}
		else if(command.equals("M_LoginMember"))
		{
			
			//로그인시 접근
			action = new M_LoginMember();	
			System.out.println("--확인용-- 여기는 ActionFactory의 M_LoginMember 분기문 ");
			
		}
		else if(command.equals("M_InsertMember")) //회원가입 
		{
			
			//회원가입시 접근		
			action  = new M_InsertMember();
			System.out.println("--확인용-- 여기는 ActionFactory의 M_InsertMember 분기문 ");
		}
		else if(command.equals("S_SellerMain"))
		{ 
			//판매자 로그인 후, 판매자 메인 페이지 버튼 클릭시 접근
			action = new S_SellerMain();			
			System.out.println("--확인용-- 여기는 ActionFactory의 S_SellerMain 분기문 ");
			
		}
		else if(command.equals("S_SellerBoardInsert"))
		{
			//판매자가 상품 올리면 여기로 옴
			action = new S_SellerBoardInsert();
			System.out.println("--확인용-- 여기는 ActionFactory의 S_SellerBoardInsert 분기문 ");
			
		}
		else if(command.equals("S_SellerBoardDetail"))
		{
			//판매자 로그인 상태에서 판매자 메인 -> 상세 보기 선택시 여기로 옴
			action = new S_SellerBoardDetail();
			
			System.out.println("--확인용-- 여기는 ActionFactory의 S_SellerBoardDetail 분기문 ");
			
		}
		else if(command.equals("S_SellerBoardEdit"))
		{
			action = new S_SellerBoardEdit();
			System.out.println("--확인용-- 여기는 ActionFactory의 S_SellerBoardEdit 분기문 ");
			
			
		}	
		else if(command.equals("S_SellerBoardUpdate"))
		{
			action = new S_SellerBoardUpdate();
			System.out.println("--확인용-- 여기는 ActionFactory의 S_SellerBoardUpdate 분기문 ");
			
		}
		else if(command.equals("S_SellerBoardDelete"))
		{
			action = new S_SellerBoardDelete();
			System.out.println("--확인용-- 여기는 ActionFactory의 S_SellerBoardDelete 분기문 ");			
			
		}
		else if(command.equals("MainPage2"))
		{
			//메인 페이지2(로그인 된) 접근시
			action = new MainPage2();
			System.out.println("--확인용-- 여기는 ActionFactory의 MainPage2 분기문 ");	
			
			
		}
		
		
		return action;
				
		
	}
	
}
